# FieldNav

**Physics-field-aware multi-objective UAV path planning** — automatic obstacle
avoidance under wind, thermal, electromagnetic-interference (EMI) and
connectivity constraints, with a learnable neural heuristic that accelerates
exact search.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.9+](https://img.shields.io/badge/Python-3.9%2B-3776AB.svg)](https://www.python.org/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.x-EE4C2C.svg)](https://pytorch.org/)

[中文说明](README.zh-CN.md) · [Methodology](docs/METHODOLOGY.md) ·
[Dataset](docs/DATASET.md) · [Experiments](docs/EXPERIMENTS.md) ·
[API](docs/API.md)

## Abstract

Planning safe and efficient trajectories for unmanned aerial vehicles (UAVs)
requires trading off many objectives at once: geometric path length, energy
consumption against a wind field, thermal exposure, electromagnetic
interference, and link quality. FieldNav formulates this as a **multi-objective
shortest-path problem over continuous, differentiable physical fields** and
ships three families of planners:

1. **Exact scalarised A\*** with an admissible, consistent heuristic;
2. **Multi-objective A\*** (Pareto label-setting) returning a non-dominated set
   of paths;
3. **RRT\*** in continuous space with field-aware steering and rewiring;
4. **Neural A\*** — a learned cost-to-go network trained by imitation of exact
   search, used as an (inflated) heuristic to trade a small optimality gap for a
   large reduction in expanded nodes and wall-clock time.

The repository includes a procedural dataset generator, a full PyTorch training
pipeline, a benchmark harness, reproducible scripts, and pre-trained weights.

## Highlights

- Five objectives: length, wind energy, thermal exposure, EMI exposure,
  connectivity risk — all differentiable w.r.t. position.
- Exact search, Pareto search, sampling-based search, and a learned heuristic
  in one codebase.
- Deterministic, seedable synthetic dataset with 3-D voxel obstacles and four
  Gaussian-mixture physical fields.
- End-to-end reproducible: one command generates data, one command trains, one
  command evaluates.
- Lightweight: the core planner is pure NumPy/SciPy; PyTorch is only needed to
  train/run the neural heuristic.

## Demo

Top-down slices with the thermal (left) and connectivity (right) fields, plus a
3-D view. Grey voxels are obstacles; green is start, red star is goal.

<p align="center">
  <img src="docs/assets/demo_2d_thermal.png" width="45%" alt="thermal slice"/>
  <img src="docs/assets/demo_2d_signal.png" width="45%" alt="signal slice"/>
</p>

<p align="center">
  <img src="docs/assets/demo_3d.png" width="70%" alt="3-D trajectories"/>
</p>

## Quickstart

```bash
git clone https://github.com/<your-account>/FieldNav.git
cd FieldNav
python -m pip install -r requirements.txt

# Generate a synthetic dataset
python scripts/generate_dataset.py --config configs/default.yaml --n 20 --out data/raw

# Train the neural heuristic
python scripts/train.py --config configs/train.yaml

# Benchmark A* vs Neural A* vs RRT*
python scripts/evaluate.py --config configs/benchmark.yaml \
    --checkpoint results/checkpoints/neural_heuristic.pt --out results

# One-scenario demo with figures
python scripts/demo.py --config configs/default.yaml \
    --checkpoint results/checkpoints/neural_heuristic.pt --out outputs
```

Run the test-suite with `python -m pytest tests -q`.

## Main results

Held-out benchmark of 20 unseen scenarios (5 m voxels, 20×20×16 grid, all four
fields enabled). Mean over scenarios; wall-clock time measured on a single CPU
core.

| Planner | Scalarised cost | Optimality gap | Nodes expanded | Time (s) |
| --- | ---: | ---: | ---: | ---: |
| A* (exact) | 348.02 | — (optimal) | 3253 | 0.31 |
| **Neural A*** | 367.23 | **+5.5%** | **143** | **0.09** |
| RRT* | 386.13 | +11.5% | — (continuous) | 13.65 |

Neural A* expands **~23× fewer nodes** and runs **~3.4× faster** than exact A*
at a 5.5% suboptimality cost, while beating the anytime RRT* baseline in both
cost and speed. Full per-scenario numbers, the training curve, and discussion of
limitations are in [docs/EXPERIMENTS.md](docs/EXPERIMENTS.md).

<p align="center">
  <img src="docs/assets/training_curve.png" width="45%" alt="training curve"/>
  <img src="docs/assets/cost_comparison.png" width="45%" alt="cost comparison"/>
</p>

## Method overview

The environment is a 3-D voxel grid with procedurally generated buildings,
towers and floating obstacles. Four smooth physical fields (wind vector field;
thermal, EMI and signal scalar fields) are sampled as Gaussian mixtures, so both
their values and gradients are available anywhere. A path's cost is the integral
of five running costs along it; the scalarised problem is solved exactly by A*,
and its Pareto front by label-setting. The neural heuristic is a small MLP that
regresses the exact cost-to-go from local features (position, goal offset, field
samples, local obstacle density), trained with a per-scenario train/val split to
avoid leakage. See [docs/METHODOLOGY.md](docs/METHODOLOGY.md).

## Repository structure

```
fieldnav/            # core package
  planners/          # A*, cost_to_go, multi-objective A*, RRT*, neural heuristic
  config.py          # typed configs + YAML loading
  cost.py            # 5-objective cost model
  fields.py          # differentiable physical fields
  grid.py            # 3-D voxel grid + occupancy
  obstacles.py       # procedural obstacle generation
  env.py             # scenario container + features
  data.py            # dataset generation + torch Dataset
  model.py           # cost-to-go MLP
  train.py           # training loop
  evaluate.py        # benchmark harness
  viz.py             # matplotlib visualisations
scripts/             # CLI entry points
configs/             # experiment configs
data/samples/        # three ready-to-load example scenarios
results/             # pre-trained weights + committed metrics (see gitignore)
docs/                # methodology, dataset, experiments, API
tests/               # unit tests
```

## Dataset

`scripts/generate_dataset.py` produces seedable `.npz` scenarios (grid,
obstacles, field parameters, start/goal, cost model). Three examples are
committed under `data/samples/`; the full dataset used for the reported numbers
is regenerated in a few minutes from the configs. See
[docs/DATASET.md](docs/DATASET.md).

## Citation

```bibtex
@misc{fieldnav2026,
  title  = {{FieldNav}: Physics-Field-Aware Multi-Objective UAV Path Planning},
  author = {FieldNav contributors},
  year   = {2026},
  note   = {Open-source software, MIT License},
  url    = {https://github.com/<your-account>/FieldNav}
}
```

## License

MIT. See [LICENSE](LICENSE).
