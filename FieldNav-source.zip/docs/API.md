# API reference

All public entry points are importable from the `fieldnav` package.

## Scenario

`fieldnav.env.Scenario` — a planning instance.

- `Scenario.generate(seed, cfg)` — build a random scenario from a `Config`.
- `Scenario.load(path)` / `scenario.save(path)` — `.npz` I/O.
- `scenario.start` / `scenario.goal` — world coordinates (m).
- `scenario.features(idx)` / `scenario.feature_matrix()` — 14-d learned features.

## Planners

`fieldnav.planners.search`:

- `a_star(scenario, weights, heuristic=None, eps=1.0)` → `(points, stats)`
- `cost_to_go(scenario, weights)` → `(n_nodes,)` ground-truth value array
- `multi_objective_a_star(scenario, max_labels, max_expansions)` →
  `(paths, cost_matrix)`

`fieldnav.planners.rrt_star`:

- `rrt_star(scenario, weights, iterations, max_dist, goal_bias, rewire_radius)`
  → `(points, stats)`

`fieldnav.planners.neural`:

- `NeuralHeuristic(model, scenario, scale)` — callable `idx → value`
- `neural_a_star(scenario, heuristic, weights, eps)` → `(points, stats)`

## Cost model

`fieldnav.cost`:

- `segment_cost_vector(a, b, fields, dyn, cost_cfg)` → 5-vector
- `path_cost_vector(points, fields, dyn, cost_cfg)` → 5-vector
- `scalarized_cost(points, fields, dyn, cost_cfg, weights)` → float
- `dominates(a, b)` / `pareto_filter(costs)`

## Training / evaluation

- `fieldnav.train.train(cfg, data_dir, checkpoint_dir)`
- `fieldnav.evaluate.evaluate(cfg, checkpoint_path, out_dir)`

## Config

`fieldnav.config.Config` — typed dataclass tree;
`load_config(path)` reads YAML. See `configs/*.yaml` for examples.
