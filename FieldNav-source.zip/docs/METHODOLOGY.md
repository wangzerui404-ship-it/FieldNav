# Methodology

## 1. Problem formulation

The workspace is an axis-aligned 3-D volume `[xmin, xmax] × [ymin, ymax] ×
[zmin, zmax]` discretised into voxels at resolution `r`. A subset of voxels is
occupied by procedurally generated obstacles (boxes, vertical cylinders,
floating spheres, plus a ground plane). A *scenario* is a tuple

```
(occupancy grid, physical fields, start, goal)
```

and the task is to find a collision-free polyline from start to goal that
minimises a vector of objectives.

## 2. Physical fields

Every field is a smooth function of position so that its value and gradient are
defined everywhere. We use isotropic Gaussian mixtures plus a uniform
background:

```
F(x) = base + Σ_k a_k · exp(-‖x - c_k‖² / (2 σ_k²))
```

- **Thermal field** `T(x)`: non-negative risk intensity (heat sources).
- **EMI field** `E(x)`: non-negative electromagnetic interference intensity.
- **Signal field** `S(x) ∈ [0, 1]`: link quality; high near base stations.
- **Wind field** `W(x) ∈ R³`: background wind plus Gaussian gusts, each with a
  random direction:
  `W(x) = w₀ + Σ_k a_k d_k · exp(-‖x-c_k‖²/(2σ_k²))`.

Field parameters are drawn by a seeded RNG; the seed fully determines a
scenario, making every result reproducible.

## 3. Trajectory cost

For a segment `(a, b)` with direction `u = (b-a)/‖b-a‖`, the five running costs
are integrated with an endpoint-averaged (first-order) quadrature:

| Objective | Segment cost |
| --- | --- |
| Length | `‖b-a‖` |
| Energy | `‖b-a‖ · (1 + γ · max(0, -u·W))` |
| Thermal | `‖b-a‖ · T̄` |
| EMI | `‖b-a‖ · Ē` |
| Connectivity | `‖b-a‖ · max(0, S_req - S̄)` |

where `T̄, Ē, S̄` are the endpoint-averaged field values, `γ` is the drag
coefficient and `S_req` the required link strength. The scalarised cost is
`c = Σᵢ wᵢ cᵢ`; the cost vector is used directly for Pareto search. Because all
running costs are non-negative, scalarised edge weights are valid graph weights.

The same quadrature is used by the grid planners (via a precomputed per-node
field cache) and by the continuous path evaluator, so search cost and reported
quality coincide exactly.

## 4. Planners

### 4.1 Exact scalarised A*

A* over the 26-connected voxel graph with the admissible, consistent heuristic

```
h(n) = (w_length + w_energy) · ‖n - goal‖₂
```

which is a lower bound because every metre of travel costs at least
`w_length + w_energy`. It returns the optimal scalarised path on the grid.

### 4.2 Multi-objective A* (Pareto label-setting)

Each node stores a set of non-dominated cost-vector labels; a label is pruned if
dominated. The number of labels per node is capped (`astar_max_labels`) and the
number of expansions is bounded (`max_expansions`) for tractability. The goal
node yields the non-dominated front of paths.

### 4.3 RRT*

Anytime RRT* in continuous space: uniform sampling with goal bias, steering,
voxelised collision checking, field-aware edge costs, and rewiring within a
radius. It is an asymptotically-optimal baseline rather than a competitor on
small grids.

### 4.4 Neural A* (learned heuristic)

The core learned component is a cost-to-go regressor. For each training
scenario, a backward Dijkstra produces the ground-truth cost-to-go `V*(n)` for
every free voxel. A small MLP maps a 14-dimensional local feature vector to
`V*(n)`:

```
features = [position/scale, (goal - position)/scale,
            T, E, S, wind/5, free_ratio, obstacle_density]
```

Training minimises mean-squared error (normalised by the mean cost-to-go) with
Adam and weight decay, using a **per-scenario** train/validation split so no
scenario leaks between splits. At inference the learned value is used as a
weighted-A* heuristic `h = ε · V̂`; larger `ε` trades optimality for speed.

## 5. Why the learned heuristic helps

The admissible Euclidean heuristic ignores all physics, so exact A* explores
large isotropic shells around the start. The learned cost-to-go folds in wind
headwind, risk fields and obstacle density, making `V̂` a much tighter estimate
of the true remaining cost. This reduces expansions dramatically. Because `V̂`
is learned (and can overestimate), weighted A* may return a slightly
suboptimal path; the optimality gap is reported explicitly in the benchmark.
