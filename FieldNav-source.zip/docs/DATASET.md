# Dataset

## Generation

```bash
python scripts/generate_dataset.py --config configs/default.yaml --n 100 --seed 0 --out data/raw
```

Each scenario is fully determined by its integer seed:

- **Grid**: `[-50, 50] × [-50, 50] × [0, 80]` m at 5 m resolution by default
  (`20 × 20 × 16` voxels).
- **Obstacles**: 8 boxes, 6 vertical cylinders and 2 floating spheres, plus a
  thin ground layer. Density/height ranges are configurable.
- **Fields**: 5 Gaussian sources per enabled field (wind, thermal, EMI, signal).
- **Endpoints**: two free voxels chosen to maximise mutual distance (a hard,
  non-trivial instance).

The reported benchmark regenerates the exact same scenarios from the committed
configs, so every number is reproducible.

## Format

Scenarios are stored as compressed NumPy archives (`.npz`) with these keys:

| Key | Description |
| --- | --- |
| `bounds` | 6-tuple world bounds |
| `resolution` | voxel size in metres |
| `occupied` | boolean voxel occupancy array |
| `fields` | serialised field parameters (centers, amplitudes, sigmas, ...) |
| `start_idx` / `goal_idx` | flat voxel indices of endpoints |
| `cost_weights` / `signal_required` / `drag_coefficient` | cost model |

Load one with `Scenario.load(path)`.

## Bundled examples

Three ready-to-load scenarios are committed under `data/samples/` for quick
experimentation without generating anything.
