# Experiments

## Setup

All numbers below were produced by the committed scripts and configs on a single
CPU core (no GPU), and can be regenerated with:

```bash
python scripts/train.py --config configs/train.yaml
python scripts/evaluate.py --config configs/benchmark.yaml \
    --checkpoint results/checkpoints/neural_heuristic.pt --out results
```

- **Training**: 60 scenarios, 1500 sampled nodes each, 30 epochs, Adam
  (`lr=1e-3`, `wd=1e-3`), batch size 512, 20% scenario-level validation split.
- **Evaluation**: 20 held-out scenarios (seeds 1000–1019), all four fields
  enabled, 5 m voxels.

## Training

The normalised MSE reaches 0.0036 (train) / 0.024 (validation). The gap is the
expected bias–variance trade-off of a 128-unit MLP on a hard 3-D value
regression task; the downstream planning metrics below show it is sufficient.

![training curve](../docs/assets/training_curve.png)

## Benchmark (20 unseen scenarios)

| Planner | Scalarised cost | Gap vs A* | Nodes expanded | Time (s) |
| --- | ---: | ---: | ---: | ---: |
| A* (exact) | 348.02 | — | 3253 | 0.31 |
| Neural A* (ε=1.5) | 367.23 | +5.5% | 143 | 0.09 |
| RRT* | 386.13 | +11.5% | — | 13.65 |

![cost comparison](../docs/assets/cost_comparison.png)

### Interpretation

- **Neural A*** expands ~23× fewer nodes and runs ~3.4× faster than exact A* at
  a 5.5% optimality gap — a favourable speed/quality trade-off.
- **RRT*** is a continuous-space anytime baseline; on 5 m voxel grids it is both
  slower and more suboptimal than the search planners, as expected. Its value is
  for fine-grained continuous planning.
- **Feasibility**: 2 of the 20 generated maps (seeds 1016, 1019) have
  disconnected free space, so no planner can find a path; they are excluded from
  the cost means. On the 18 connected maps, both search planners succeed every
  time, and RRT* connects in 17 of 18 (94%) within 2000 iterations.

The raw per-scenario table is in `results/metrics.json`; the training history is
in `results/training_history.json`.

## Ablation: heuristic inflation ε

`configs/benchmark.yaml` exposes `planner.weighted_astar_eps`. Larger ε inflates
the learned heuristic, expanding fewer nodes but accepting larger suboptimality;
ε=1.0 with an exactly-admissible learned heuristic would remain optimal, but the
learned regressor is only approximately admissible. ε=1.5 is the default balance.

## Limitations

- Fields are Gaussian mixtures; arbitrary maps require the provided interfaces.
- The neural heuristic is trained per weight vector; a different
  `cost.weights` needs retraining (a multi-head network is future work).
- Pareto label-setting scales poorly with grid size; it is intended for
  analysis on coarser grids rather than as a production planner.
