"""Typed configuration objects and YAML loading for FieldNav.

Every experiment (dataset generation, training, evaluation, demo) is driven by a
``Config`` tree.  The dataclasses below are intentionally dependency-free so the
core planner can be imported without PyTorch/YAML installed.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class GridConfig:
    """Axis-aligned bounding box and voxel resolution of the planning volume."""

    bounds: Tuple[float, float, float, float, float, float] = (-50.0, 50.0, -50.0, 50.0, 0.0, 80.0)
    resolution: float = 4.0  # metres per voxel edge

    @property
    def shape(self) -> Tuple[int, int, int]:
        xmin, xmax, ymin, ymax, zmin, zmax = self.bounds
        nx = int(round((xmax - xmin) / self.resolution))
        ny = int(round((ymax - ymin) / self.resolution))
        nz = int(round((zmax - zmin) / self.resolution))
        return nx, ny, nz


@dataclass
class ObstacleConfig:
    """Procedural obstacle generation parameters (see ``fieldnav.obstacles``)."""

    n_boxes: int = 8
    n_cylinders: int = 6
    n_spheres: int = 2
    box_height_range: Tuple[float, float] = (10.0, 45.0)
    cylinder_height_range: Tuple[float, float] = (15.0, 60.0)
    sphere_radius_range: Tuple[float, float] = (3.0, 9.0)
    ground_clearance: float = 1.0  # keep at least this much free above z=0


@dataclass
class FieldConfig:
    """Independent toggles/parameters for each differentiable physical field."""

    wind: bool = True
    thermal: bool = True
    emi: bool = True
    signal: bool = True
    n_sources: int = 5          # Gaussian sources per enabled field
    source_strength: Tuple[float, float] = (0.2, 1.0)
    source_radius: Tuple[float, float] = (8.0, 28.0)
    base_value: float = 0.05    # uniform background intensity (>= 0)


@dataclass
class DynamicsConfig:
    """Simplified quadrotor energy model."""

    cruise_speed: float = 6.0       # m/s
    hover_power: float = 120.0      # W (unused in path cost, kept for clarity)
    drag_coefficient: float = 0.08  # extra energy per unit headwind speed
    max_turn_angle: float = 0.9     # rad, used by RRT* steering


@dataclass
class CostConfig:
    """Weights of the five objectives in the scalarized cost."""

    length: float = 1.0
    energy: float = 0.5
    thermal: float = 1.0
    emi: float = 1.0
    comm: float = 1.0
    signal_required: float = 0.6  # connectivity threshold for comm risk

    @property
    def vector(self) -> List[float]:
        return [self.length, self.energy, self.thermal, self.emi, self.comm]


@dataclass
class PlannerConfig:
    """Planner-specific hyper-parameters."""

    connectivity: int = 26
    astar_max_labels: int = 64       # Pareto-label cap for multi-objective A*
    rrt_star_iterations: int = 3000
    rrt_star_radius: float = 25.0
    rrt_star_goal_bias: float = 0.15
    weighted_astar_eps: float = 1.5  # inflation for the learned heuristic


@dataclass
class ScenarioConfig:
    """One generated benchmark scenario."""

    seed: int = 0
    grid: GridConfig = field(default_factory=GridConfig)
    obstacles: ObstacleConfig = field(default_factory=ObstacleConfig)
    fields: FieldConfig = field(default_factory=FieldConfig)
    start: Optional[Tuple[float, float, float]] = None
    goal: Optional[Tuple[float, float, float]] = None


@dataclass
class ModelConfig:
    """Neural cost-to-go model."""

    hidden_dim: int = 128
    n_layers: int = 3
    field_features: int = 4  # wind-head, thermal, emi, signal at the node
    goal_features: int = 3
    position_features: int = 3
    obstacle_features: int = 2  # local free ratio + distance-to-nearest-obstacle


@dataclass
class TrainConfig:
    """Supervised training of the neural heuristic."""

    n_scenarios: int = 60
    samples_per_scenario: int = 2000
    val_split: float = 0.2
    epochs: int = 40
    batch_size: int = 512
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    seed: int = 0
    model: ModelConfig = field(default_factory=ModelConfig)


@dataclass
class EvalConfig:
    """Benchmark evaluation settings."""

    n_scenarios: int = 20
    seed: int = 1000
    checkpoint: Optional[str] = None


@dataclass
class Config:
    """Top-level configuration bundling every subsystem."""

    grid: GridConfig = field(default_factory=GridConfig)
    obstacles: ObstacleConfig = field(default_factory=ObstacleConfig)
    fields: FieldConfig = field(default_factory=FieldConfig)
    dynamics: DynamicsConfig = field(default_factory=DynamicsConfig)
    cost: CostConfig = field(default_factory=CostConfig)
    planner: PlannerConfig = field(default_factory=PlannerConfig)
    scenario: ScenarioConfig = field(default_factory=ScenarioConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    eval: EvalConfig = field(default_factory=EvalConfig)


def _asdict(obj: Any) -> Any:
    if hasattr(obj, "__dataclass_fields__"):
        return {f.name: _asdict(getattr(obj, f.name)) for f in fields(obj)}
    if isinstance(obj, (list, tuple)):
        return [_asdict(x) for x in obj]
    return obj


def to_dict(cfg: Config) -> Dict[str, Any]:
    return _asdict(cfg)


def _set_known(dc: Any, data: Dict[str, Any]) -> None:
    """Recursively assign known keys, ignoring unknown ones for forward-compat."""

    for f in fields(dc):
        if f.name not in data:
            continue
        value = data[f.name]
        current = getattr(dc, f.name)
        if hasattr(current, "__dataclass_fields__") and isinstance(value, dict):
            _set_known(current, value)
        elif hasattr(current, "__dataclass_fields__"):
            _set_known(current, _asdict(value))
        else:
            setattr(dc, f.name, value)


def from_dict(data: Dict[str, Any]) -> Config:
    cfg = Config()
    _set_known(cfg, data)
    return cfg


def load_config(path: str) -> Config:
    """Load a YAML config file, falling back to an empty dict when unavailable."""

    try:
        import yaml
    except ImportError:  # pragma: no cover - yaml is a soft dependency
        return Config()
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return from_dict(data)
