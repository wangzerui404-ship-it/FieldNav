"""Scenario container: grid + physical fields + start/goal, plus I/O and
feature extraction for learning."""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

import numpy as np

from .config import Config, CostConfig, DynamicsConfig
from .fields import FieldSet, generate_fields
from .grid import Grid3D
from .obstacles import generate_obstacles


class Scenario:
    """A single planning instance."""

    def __init__(
        self,
        grid: Grid3D,
        fields: FieldSet,
        start_idx: int,
        goal_idx: int,
        seed: int = 0,
        dyn: Optional[DynamicsConfig] = None,
        cost_cfg: Optional[CostConfig] = None,
    ) -> None:
        self.grid = grid
        self.fields = fields
        self.start_idx = int(start_idx)
        self.goal_idx = int(goal_idx)
        self.seed = int(seed)
        self.dyn = dyn or DynamicsConfig()
        self.cost_cfg = cost_cfg or CostConfig()

    @property
    def start(self) -> np.ndarray:
        return self.grid.index_to_world(self.start_idx)

    @property
    def goal(self) -> np.ndarray:
        return self.grid.index_to_world(self.goal_idx)

    # ----- construction ----------------------------------------------------
    @classmethod
    def generate(cls, seed: int, cfg: Config) -> "Scenario":
        rng = np.random.default_rng(seed)
        grid = Grid3D(cfg.grid.bounds, cfg.grid.resolution)
        generate_obstacles(grid, cfg.obstacles, rng)
        fields = generate_fields(cfg.fields, rng, cfg.grid.bounds)
        start_idx, goal_idx = cls._choose_endpoints(grid, rng)
        return cls(
            grid,
            fields,
            start_idx,
            goal_idx,
            seed=seed,
            dyn=cfg.dynamics,
            cost_cfg=cfg.cost,
        )

    @staticmethod
    def _choose_endpoints(
        grid: Grid3D, rng: np.random.Generator
    ) -> Tuple[int, int]:
        free = np.flatnonzero(grid.free_mask())
        if free.size < 2:
            raise ValueError("scenario has fewer than two free voxels")
        sample = rng.choice(free, size=min(64, free.size), replace=False)
        best = (sample[0], sample[1])
        best_d = -1.0
        coords = np.stack([grid.index_to_world(i) for i in sample])
        for i in range(len(sample)):
            for j in range(i + 1, len(sample)):
                d = float(np.linalg.norm(coords[i] - coords[j]))
                if d > best_d:
                    best_d = d
                    best = (sample[i], sample[j])
        return int(best[0]), int(best[1])

    # ----- sampling / features ---------------------------------------------
    def sample_free_world(self, n: int, rng: np.random.Generator) -> np.ndarray:
        free = np.flatnonzero(self.grid.free_mask())
        idx = rng.choice(free, size=n, replace=True)
        return np.stack([self.grid.index_to_world(i) for i in idx])

    def features(self, idx: int) -> np.ndarray:
        """Compact local feature vector used by the neural heuristic.

        Layout (14-d): position(3), goal offset(3), thermal/emi/signal(3),
        wind vector(3), local free ratio(1), local obstacle density(1).
        """

        pos = self.grid.index_to_world(idx)
        goal = self.grid.index_to_world(self.goal_idx)
        scale = np.array(
            [
                self.grid.xmax - self.grid.xmin,
                self.grid.ymax - self.grid.ymin,
                self.grid.zmax - self.grid.zmin,
            ]
        )
        scalars = self.fields.scalars(pos[None, :])
        thermal = float(scalars.get("thermal", np.array([0.0]))[0])
        emi = float(scalars.get("emi", np.array([0.0]))[0])
        signal = float(scalars.get("signal", np.array([1.0]))[0])
        wind = self.fields.wind_vector(pos[None, :])[0]

        nbh = [j for j in self.grid.neighbor_list(idx)]
        n_free = sum(1 for j in nbh if self.grid.is_free(j))
        free_ratio = (n_free + 1) / (len(nbh) + 1) if nbh else 1.0
        obs_density = 1.0 - free_ratio

        return np.concatenate(
            [
                pos / scale,
                (goal - pos) / scale,
                np.array([thermal, emi, signal]),
                wind / 5.0,
                np.array([free_ratio, obs_density]),
            ]
        ).astype(np.float32)

    def feature_matrix(self) -> np.ndarray:
        """Vectorised ``(n_nodes, 14)`` features for the whole grid.

        Identical layout to :meth:`features`; precomputing it once makes the
        learned heuristic an O(1) lookup plus a single small network forward.
        """

        grid = self.grid
        centers = np.stack([grid.index_to_world(i) for i in range(grid.n_nodes)])
        goal = centers[self.goal_idx]
        scale = np.array(
            [
                grid.xmax - grid.xmin,
                grid.ymax - grid.ymin,
                grid.zmax - grid.zmin,
            ]
        )
        scalars = self.fields.scalars(centers)
        thermal = scalars.get("thermal", np.zeros(grid.n_nodes))
        emi = scalars.get("emi", np.zeros(grid.n_nodes))
        signal = scalars.get("signal", np.ones(grid.n_nodes))
        wind = self.fields.wind_vector(centers)

        nb = grid.neighbors
        valid = nb >= 0
        nb_clipped = np.clip(nb, 0, grid.n_nodes - 1)
        free_mask = grid.free_mask()
        free_nb = np.where(valid, free_mask[nb_clipped], 0)
        n_valid = valid.sum(axis=1).astype(np.float32)
        free_ratio = (free_nb.sum(axis=1).astype(np.float32) + 1.0) / (n_valid + 1.0)
        obs_density = 1.0 - free_ratio

        return np.concatenate(
            [
                centers / scale,
                (goal - centers) / scale,
                np.stack([thermal, emi, signal], axis=1),
                wind / 5.0,
                free_ratio[:, None],
                obs_density[:, None],
            ],
            axis=1,
        ).astype(np.float32)

    @property
    def feature_dim(self) -> int:
        return int(self.features(self.start_idx).size)

    # ----- serialization ----------------------------------------------------
    def to_state(self) -> Dict[str, Any]:
        return {
            "seed": self.seed,
            "bounds": [
                self.grid.xmin,
                self.grid.xmax,
                self.grid.ymin,
                self.grid.ymax,
                self.grid.zmin,
                self.grid.zmax,
            ],
            "resolution": self.grid.resolution,
            "occupied": self.grid.occupied,
            "fields": self.fields.to_state(),
            "start_idx": self.start_idx,
            "goal_idx": self.goal_idx,
            "cost_weights": list(self.cost_cfg.vector),
            "signal_required": self.cost_cfg.signal_required,
            "drag_coefficient": self.dyn.drag_coefficient,
        }

    @classmethod
    def from_state(cls, state: Dict[str, Any]) -> "Scenario":
        grid = Grid3D(
            tuple(state["bounds"]),
            state["resolution"],
            occupied=np.asarray(state["occupied"], dtype=bool),
        )
        fields = FieldSet.from_state(state["fields"])
        cost_cfg = CostConfig()
        if "cost_weights" in state:
            cost_cfg.length, cost_cfg.energy, cost_cfg.thermal, cost_cfg.emi, cost_cfg.comm = (
                [float(x) for x in state["cost_weights"]] + [cost_cfg.comm]
            )[:5]
        if "signal_required" in state:
            cost_cfg.signal_required = float(state["signal_required"])
        dyn = DynamicsConfig()
        if "drag_coefficient" in state:
            dyn.drag_coefficient = float(state["drag_coefficient"])
        return cls(
            grid,
            fields,
            int(state["start_idx"]),
            int(state["goal_idx"]),
            seed=int(state["seed"]),
            dyn=dyn,
            cost_cfg=cost_cfg,
        )

    def save(self, path: str) -> None:
        np.savez_compressed(path, **self.to_state())

    @classmethod
    def load(cls, path: str) -> "Scenario":
        data = np.load(path, allow_pickle=True)
        return cls.from_state(dict(data))
