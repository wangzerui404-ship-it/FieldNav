"""Dataset generation and PyTorch batching for the neural heuristic."""

from __future__ import annotations

import os
from typing import List, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

from .config import Config
from .env import Scenario
from .planners.search import cost_to_go


def generate_scenarios(
    n: int,
    start_seed: int,
    cfg: Config,
    out_dir: str | None = None,
) -> List[Scenario]:
    """Generate ``n`` scenarios with seeds ``start_seed .. start_seed+n-1``."""

    scenarios: List[Scenario] = []
    os.makedirs(out_dir, exist_ok=True) if out_dir else None
    for i in range(n):
        seed = start_seed + i
        scenario = Scenario.generate(seed, cfg)
        if out_dir:
            scenario.save(os.path.join(out_dir, f"scenario_{seed:05d}.npz"))
        scenarios.append(scenario)
    return scenarios


def scenario_features_targets(
    scenario: Scenario,
    weights: Sequence[float],
    n_samples: int,
    rng: np.random.Generator,
) -> Tuple[np.ndarray, np.ndarray]:
    """Sample free nodes and return ``(features, cost-to-go targets)``."""

    dist = cost_to_go(scenario, weights)
    free = np.flatnonzero((scenario.grid.free_mask()) & np.isfinite(dist))
    if free.size == 0:
        return np.zeros((0, scenario.feature_dim), dtype=np.float32), np.zeros(0, dtype=np.float32)
    idx = rng.choice(free, size=min(n_samples, free.size), replace=False)
    F = scenario.feature_matrix()
    X = F[idx]
    y = dist[idx].astype(np.float32)
    return X, y


class CostToGoDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray) -> None:
        self.X = torch.from_numpy(np.asarray(X, dtype=np.float32))
        self.y = torch.from_numpy(np.asarray(y, dtype=np.float32))

    def __len__(self) -> int:
        return self.X.shape[0]

    def __getitem__(self, i: int) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.X[i], self.y[i]
