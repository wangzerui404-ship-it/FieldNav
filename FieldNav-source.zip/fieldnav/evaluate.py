"""Benchmark: exact A* vs learned-heuristic A* vs RRT*."""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List

import numpy as np
import torch

from .config import Config, ModelConfig
from .data import generate_scenarios
from .env import Scenario
from .metrics import aggregate, path_metrics
from .model import build_model
from .planners.neural import NeuralHeuristic, neural_a_star
from .planners.rrt_star import rrt_star
from .planners.search import a_star
from .utils import ensure_dir
from .viz import plot_2d, plot_3d, plot_comparison


def load_checkpoint(path: str) -> tuple[torch.nn.Module, float]:
    ckpt = torch.load(path, map_location="cpu")
    model = build_model(
        ckpt["feature_dim"],
        ModelConfig(hidden_dim=ckpt["hidden_dim"], n_layers=ckpt["n_layers"]),
    )
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    return model, float(ckpt["scale"])


def evaluate(
    cfg: Config,
    checkpoint_path: str,
    out_dir: str = "results",
    make_plots: bool = True,
) -> Dict[str, Any]:
    """Run the benchmark and persist metrics, JSON, and figures."""

    ensure_dir(out_dir)
    weights = np.asarray(cfg.cost.vector, dtype=np.float64)
    model, scale = load_checkpoint(checkpoint_path)
    scenarios = generate_scenarios(
        cfg.eval.n_scenarios, start_seed=cfg.eval.seed, cfg=cfg
    )

    rows: List[Dict[str, float]] = []
    costs_by_planner: Dict[str, List[float]] = {"A* (exact)": [], "Neural A*": [], "RRT*": []}
    demo_scenario: Scenario | None = None
    demo_paths: Dict[str, np.ndarray] = {}

    for si, s in enumerate(scenarios):
        path_exact, stats_exact = a_star(s, weights)
        neural_h = NeuralHeuristic(model, s, scale=scale)
        path_neural, stats_neural = neural_a_star(
            s, neural_h, weights, eps=cfg.planner.weighted_astar_eps
        )
        path_rrt, stats_rrt = rrt_star(
            s,
            weights,
            iterations=cfg.planner.rrt_star_iterations,
            max_dist=cfg.grid.resolution * 1.5,
            goal_bias=cfg.planner.rrt_star_goal_bias,
            rewire_radius=cfg.planner.rrt_star_radius,
        )

        m_exact = path_metrics(path_exact, s, weights)
        m_neural = path_metrics(path_neural, s, weights)
        m_rrt = path_metrics(path_rrt, s, weights)

        optimal = m_exact["cost"]
        rows.append(
            {
                "cost_exact": optimal,
                "cost_neural": m_neural["cost"],
                "cost_rrt": m_rrt["cost"],
                "gap_neural": (m_neural["cost"] - optimal) / optimal if optimal > 0 else 0.0,
                "gap_rrt": (m_rrt["cost"] - optimal) / optimal if optimal > 0 else float("inf"),
                "nodes_exact": stats_exact["nodes_expanded"],
                "nodes_neural": stats_neural["nodes_expanded"],
                "time_exact": stats_exact["time_s"],
                "time_neural": stats_neural["time_s"],
                "time_rrt": stats_rrt["time_s"],
                "length_exact": m_exact["length"],
                "length_neural": m_neural["length"],
                "length_rrt": m_rrt["length"],
            }
        )
        for planner, m, pts in (
            ("A* (exact)", m_exact, path_exact),
            ("Neural A*", m_neural, path_neural),
            ("RRT*", m_rrt, path_rrt),
        ):
            costs_by_planner[planner].append(m["cost"])

        if si == 0:
            demo_scenario = s
            demo_paths = {
                "A* (exact)": path_exact,
                "Neural A*": path_neural,
                "RRT*": path_rrt,
            }
        print(
            f"scenario {cfg.eval.seed + si:5d}  "
            f"exact={optimal:8.2f}  neural={m_neural['cost']:8.2f}  "
            f"rrt*={m_rrt['cost']:8.2f}"
        )

    agg = aggregate(rows)
    metrics_path = os.path.join(out_dir, "metrics.json")
    with open(metrics_path, "w", encoding="utf-8") as fh:
        json.dump({"aggregate": agg, "per_scenario": rows}, fh, indent=2)

    if make_plots and demo_scenario is not None:
        fig_dir = os.path.join(out_dir, "figures")
        ensure_dir(fig_dir)
        plot_2d(demo_scenario, demo_paths, field_name="thermal", save_path=os.path.join(fig_dir, "demo_2d_thermal.png"))
        plot_2d(demo_scenario, demo_paths, field_name="signal", save_path=os.path.join(fig_dir, "demo_2d_signal.png"))
        plot_3d(demo_scenario, demo_paths, save_path=os.path.join(fig_dir, "demo_3d.png"))
        plot_comparison(costs_by_planner, "scalarised cost", save_path=os.path.join(fig_dir, "cost_comparison.png"))

    return {"aggregate": agg, "rows": rows, "metrics_path": metrics_path}
