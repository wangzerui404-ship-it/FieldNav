"""Simplified quadrotor kinematics and geometry helpers."""

from __future__ import annotations

import numpy as np


def steer(a: np.ndarray, b: np.ndarray, max_dist: float) -> np.ndarray:
    """Move from ``a`` towards ``b`` by at most ``max_dist`` metres."""

    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    delta = b - a
    dist = float(np.linalg.norm(delta))
    if dist <= max_dist or dist < 1e-9:
        return b.copy()
    return a + delta * (max_dist / dist)


def turning_penalty(points: np.ndarray, kappa: float = 0.05) -> float:
    """Accumulated heading-change penalty over a polyline (smoothness proxy)."""

    pts = np.asarray(points, dtype=np.float64)
    if len(pts) < 3:
        return 0.0
    total = 0.0
    for i in range(1, len(pts) - 1):
        d1 = pts[i] - pts[i - 1]
        d2 = pts[i + 1] - pts[i]
        n1 = np.linalg.norm(d1)
        n2 = np.linalg.norm(d2)
        if n1 < 1e-9 or n2 < 1e-9:
            continue
        cos_angle = float(np.dot(d1, d2) / (n1 * n2))
        cos_angle = min(1.0, max(-1.0, cos_angle))
        total += 1.0 - cos_angle
    return kappa * total
