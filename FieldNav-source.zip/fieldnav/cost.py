"""Multi-objective trajectory cost under continuous physical fields.

The cost of a polyline is the integral of five running costs along it:

1. **length**      — geometric distance (metres).
2. **energy**      — length scaled by headwind work against the wind field.
3. **thermal**     — exposure to the thermal risk field.
4. **emi**         — exposure to the electromagnetic-interference field.
5. **comm**        — connectivity risk: how far signal strength drops below the
   required threshold along the route.

Every running cost is non-negative, so the scalarised edge cost is a valid,
non-negative graph weight for Dijkstra/A* search.
"""

from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np

from .config import CostConfig, DynamicsConfig
from .fields import FieldSet


COST_NAMES = ("length", "energy", "thermal", "emi", "comm")


def segment_cost_vector(
    a: np.ndarray,
    b: np.ndarray,
    fields: FieldSet,
    dyn: DynamicsConfig,
    cost_cfg: CostConfig,
) -> np.ndarray:
    """Return the 5-component cost of a straight segment.

    The running cost is evaluated at both endpoints and averaged (a first-order
    quadrature of the field integral along the segment).  This is the single
    canonical cost used by search, sampling-based planners, and evaluation.
    """

    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    length = float(np.linalg.norm(b - a))
    if length < 1e-9:
        return np.zeros(5)

    direction = (b - a) / length
    pts = np.stack([a, b])
    wind = fields.wind_vector(pts).mean(axis=0)
    headwind = max(0.0, -float(np.dot(direction, wind)))
    energy = length * (1.0 + dyn.drag_coefficient * headwind)

    scalars = fields.scalars(pts)
    thermal = length * float(scalars.get("thermal", np.array([0.0, 0.0])).mean())
    emi = length * float(scalars.get("emi", np.array([0.0, 0.0])).mean())

    signal = float(scalars.get("signal", np.array([cost_cfg.signal_required] * 2)).mean())
    comm = length * max(0.0, cost_cfg.signal_required - signal)

    return np.array([length, energy, thermal, emi, comm], dtype=np.float64)


def sample_node_fields(grid, fields: FieldSet):
    """Precompute field values at every voxel centre for fast graph search.

    Returns ``(centers, wind, scalars)`` where ``centers`` is ``(N, 3)``,
    ``wind`` is ``(N, 3)`` and ``scalars`` is ``{name: (N,)}`` for each enabled
    scalar field.  Used by ``segment_cost_from_cache`` below.
    """

    centers = np.stack([grid.index_to_world(i) for i in range(grid.n_nodes)])
    wind = fields.wind_vector(centers)
    scalars = fields.scalars(centers)
    return centers, wind, scalars


def segment_cost_from_cache(
    u: int,
    v: int,
    centers: np.ndarray,
    wind: np.ndarray,
    scalars: Dict[str, np.ndarray],
    dyn: DynamicsConfig,
    cost_cfg: CostConfig,
) -> np.ndarray:
    """5-component cost of the grid edge ``u->v`` from precomputed node fields.

    Matches :func:`segment_cost_vector` exactly (endpoint-averaged quadrature),
    which guarantees the graph planner and the continuous evaluator agree.
    """

    a = centers[u]
    b = centers[v]
    length = float(np.linalg.norm(b - a))
    if length < 1e-9:
        return np.zeros(5)
    direction = (b - a) / length
    wind_avg = 0.5 * (wind[u] + wind[v])
    headwind = max(0.0, -float(np.dot(direction, wind_avg)))
    energy = length * (1.0 + dyn.drag_coefficient * headwind)

    thermal = length * (
        (float(scalars["thermal"][u]) if "thermal" in scalars else 0.0)
        + (float(scalars["thermal"][v]) if "thermal" in scalars else 0.0)
    ) / 2.0
    emi = length * (
        (float(scalars["emi"][u]) if "emi" in scalars else 0.0)
        + (float(scalars["emi"][v]) if "emi" in scalars else 0.0)
    ) / 2.0
    s_u = float(scalars["signal"][u]) if "signal" in scalars else cost_cfg.signal_required
    s_v = float(scalars["signal"][v]) if "signal" in scalars else cost_cfg.signal_required
    comm = length * max(0.0, cost_cfg.signal_required - 0.5 * (s_u + s_v))
    return np.array([length, energy, thermal, emi, comm], dtype=np.float64)


def path_cost_vector(
    points: np.ndarray,
    fields: FieldSet,
    dyn: DynamicsConfig,
    cost_cfg: CostConfig,
) -> np.ndarray:
    """Integrate the running cost along a polyline (N x 3)."""

    points = np.asarray(points, dtype=np.float64)
    total = np.zeros(5)
    for i in range(len(points) - 1):
        total += segment_cost_vector(points[i], points[i + 1], fields, dyn, cost_cfg)
    return total


def scalarized_cost(
    points: np.ndarray,
    fields: FieldSet,
    dyn: DynamicsConfig,
    cost_cfg: CostConfig,
    weights: Sequence[float] = (1.0, 0.5, 1.0, 1.0, 1.0),
) -> float:
    return float(np.dot(path_cost_vector(points, fields, dyn, cost_cfg), np.asarray(weights)))


def dominates(a: np.ndarray, b: np.ndarray) -> bool:
    """True if cost vector ``a`` Pareto-dominates ``b``."""

    return bool(np.all(a <= b) and np.any(a < b))


def pareto_filter(costs: np.ndarray) -> np.ndarray:
    """Return indices of the Pareto-non-dominated rows of ``costs``."""

    costs = np.asarray(costs, dtype=np.float64)
    n = costs.shape[0]
    keep = np.ones(n, dtype=bool)
    for i in range(n):
        if not keep[i]:
            continue
        for j in range(n):
            if i != j and keep[j] and dominates(costs[j], costs[i]):
                keep[i] = False
                break
    return np.flatnonzero(keep)


def summarize_costs(costs: np.ndarray) -> Dict[str, float]:
    """Label a 5-component cost vector with human-readable names."""

    return {name: float(costs[i]) for i, name in enumerate(COST_NAMES)}
