"""Shared helpers: seeding, timers, and small numeric utilities."""

from __future__ import annotations

import os
import random
import time
from contextlib import contextmanager
from typing import Iterator, Optional

import numpy as np


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ.setdefault("PYTHONHASHSEED", str(seed))


@contextmanager
def timer(name: Optional[str] = None) -> Iterator[None]:
    """Context manager that prints elapsed wall time (used by scripts)."""

    t0 = time.perf_counter()
    yield
    dt = time.perf_counter() - t0
    label = f" [{name}]" if name else ""
    print(f"elapsed{label}: {dt:.3f}s")


def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(x, 0.0)


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path
