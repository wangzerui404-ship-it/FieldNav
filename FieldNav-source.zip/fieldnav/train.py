"""Supervised training of the neural cost-to-go heuristic."""

from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from .config import Config
from .data import generate_scenarios, scenario_features_targets
from .model import build_model
from .utils import ensure_dir, set_seed


def train(
    cfg: Config,
    data_dir: str = "data/raw",
    checkpoint_dir: str = "results/checkpoints",
) -> Dict[str, object]:
    """Train and return ``{"history": {...}, "checkpoint": path, "scale": ...}``."""

    set_seed(cfg.train.seed)
    weights = cfg.cost.vector
    scenarios = generate_scenarios(
        cfg.train.n_scenarios, start_seed=0, cfg=cfg, out_dir=data_dir
    )
    feature_dim = scenarios[0].feature_dim

    # Sample features/targets, then split by *scenario* to avoid leakage.
    rng = np.random.default_rng(cfg.train.seed)
    Xs, ys = [], []
    for s in scenarios:
        X, y = scenario_features_targets(s, weights, cfg.train.samples_per_scenario, rng)
        Xs.append(X)
        ys.append(y)

    idx = np.arange(len(scenarios))
    rng.shuffle(idx)
    n_val = max(1, int(cfg.train.val_split * len(scenarios)))
    val_idx = set(idx[:n_val].tolist())

    def stack(sel):
        x = np.vstack([Xs[i] for i in sel])
        y = np.concatenate([ys[i] for i in sel])
        return x, y

    X_train, y_train = stack([i for i in range(len(scenarios)) if i not in val_idx])
    X_val, y_val = stack([i for i in range(len(scenarios)) if i in val_idx])

    scale = max(float(np.mean(y_train)), 1e-3)
    y_train = (y_train / scale).astype(np.float32)
    y_val = (y_val / scale).astype(np.float32)

    train_ds = TensorDataset(
        torch.from_numpy(X_train), torch.from_numpy(y_train)
    )
    val_ds = TensorDataset(torch.from_numpy(X_val), torch.from_numpy(y_val))
    train_loader = DataLoader(train_ds, batch_size=cfg.train.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=cfg.train.batch_size)

    model = build_model(feature_dim, cfg.train.model, seed=cfg.train.seed)
    optimizer = torch.optim.Adam(
        model.parameters(), lr=cfg.train.learning_rate, weight_decay=cfg.train.weight_decay
    )
    loss_fn = nn.MSELoss()

    history: Dict[str, List[float]] = {"train": [], "val": []}
    for epoch in range(cfg.train.epochs):
        model.train()
        losses = []
        for xb, yb in train_loader:
            optimizer.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.item()))
        model.eval()
        val_losses = []
        with torch.no_grad():
            for xb, yb in val_loader:
                val_losses.append(float(loss_fn(model(xb), yb).item()))
        history["train"].append(float(np.mean(losses)))
        history["val"].append(float(np.mean(val_losses)))
        print(
            f"epoch {epoch + 1:3d}/{cfg.train.epochs}  "
            f"train_mse={history['train'][-1]:.4f}  val_mse={history['val'][-1]:.4f}"
        )

    ensure_dir(checkpoint_dir)
    ckpt_path = os.path.join(checkpoint_dir, "neural_heuristic.pt")
    torch.save(
        {
            "state_dict": model.state_dict(),
            "feature_dim": feature_dim,
            "hidden_dim": cfg.train.model.hidden_dim,
            "n_layers": cfg.train.model.n_layers,
            "scale": scale,
            "config": json.dumps(_config_summary(cfg)),
        },
        ckpt_path,
    )
    return {"history": history, "checkpoint": ckpt_path, "scale": scale}


def _config_summary(cfg: Config) -> Dict[str, object]:
    return {
        "cost_weights": cfg.cost.vector,
        "signal_required": cfg.cost.signal_required,
        "grid_bounds": list(cfg.grid.bounds),
        "grid_resolution": cfg.grid.resolution,
        "weighted_astar_eps": cfg.planner.weighted_astar_eps,
    }
