"""Matplotlib visualisations for scenarios, paths, and training curves."""

from __future__ import annotations

import os
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .env import Scenario


PATH_COLORS = {
    "A* (exact)": "#1f77b4",
    "Neural A*": "#ff7f0e",
    "RRT*": "#2ca02c",
}


def _field_slice(
    scenario: Scenario, field_name: str, z: float
) -> Tuple[np.ndarray, Tuple[float, float, float, float]]:
    grid = scenario.grid
    xs = grid.xmin + (np.arange(grid.nx) + 0.5) * grid.resolution
    ys = grid.ymin + (np.arange(grid.ny) + 0.5) * grid.resolution
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    pts = np.stack([X.ravel(), Y.ravel(), np.full(X.size, z)], axis=1)
    field = getattr(scenario.fields, field_name)
    Z = field.sample(pts).reshape(X.shape)
    extent = (grid.xmin, grid.xmax, grid.ymin, grid.ymax)
    return Z, extent


def plot_2d(
    scenario: Scenario,
    paths: Dict[str, np.ndarray],
    field_name: str = "thermal",
    save_path: Optional[str] = None,
) -> None:
    """Top-down slice with a physical-field heatmap and the planned routes."""

    grid = scenario.grid
    z = float(scenario.start[2])
    iz = max(0, min(grid.nz - 1, grid.cell(0.0, 0.0, z)[2]))
    Z, extent = _field_slice(scenario, field_name, z)
    occ = grid.occupied[:, :, iz]

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(
        Z.T,
        origin="lower",
        extent=extent,
        cmap="plasma",
        alpha=0.85,
        aspect="auto",
    )
    ax.imshow(
        occ.T,
        origin="lower",
        extent=extent,
        cmap="Greys",
        alpha=0.55,
        aspect="auto",
        vmin=0,
        vmax=1,
    )
    for name, pts in paths.items():
        if len(pts) == 0:
            continue
        ax.plot(pts[:, 0], pts[:, 1], color=PATH_COLORS.get(name, "black"), lw=2, label=name)
    ax.scatter(*scenario.start[:2], c="green", s=120, marker="o", label="start", edgecolors="k")
    ax.scatter(*scenario.goal[:2], c="red", s=140, marker="*", label="goal", edgecolors="k")
    ax.set_xlim(grid.xmin, grid.xmax)
    ax.set_ylim(grid.ymin, grid.ymax)
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title(f"{field_name} field slice at z={z:.0f} m (grey = obstacles)")
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label(field_name)
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150)
    plt.close(fig)


def plot_3d(
    scenario: Scenario,
    paths: Dict[str, np.ndarray],
    save_path: Optional[str] = None,
) -> None:
    """3-D view of routes through a downsampled occupancy volume."""

    grid = scenario.grid
    fig = plt.figure(figsize=(8, 7))
    ax = fig.add_subplot(111, projection="3d")

    ds = max(1, min(grid.nx, grid.ny, grid.nz) // 8)
    occ = grid.occupied[::ds, ::ds, ::ds]
    if occ.size and occ.any():
        ax.voxels(occ, facecolors="#777777", edgecolor="#555555", alpha=0.22, shade=False)

    for name, pts in paths.items():
        if len(pts) == 0:
            continue
        ax.plot(pts[:, 0], pts[:, 1], pts[:, 2], color=PATH_COLORS.get(name, "black"), lw=2, label=name)
    ax.scatter(*scenario.start, c="green", s=90, marker="o", label="start")
    ax.scatter(*scenario.goal, c="red", s=120, marker="*", label="goal")
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_zlabel("z (m)")
    ax.set_title("3-D planned trajectories")
    ax.legend(loc="upper left", fontsize=8)
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150)
    plt.close(fig)


def plot_training_curve(
    history: Dict[str, List[float]], save_path: Optional[str] = None
) -> None:
    fig, ax = plt.subplots(figsize=(6, 4))
    epochs = np.arange(1, len(history["train"]) + 1)
    ax.plot(epochs, history["train"], label="train MSE", color="#1f77b4")
    ax.plot(epochs, history["val"], label="val MSE", color="#d62728")
    ax.set_xlabel("epoch")
    ax.set_ylabel("MSE (normalised cost-to-go)")
    ax.set_yscale("log")
    ax.set_title("Neural heuristic training")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150)
    plt.close(fig)


def plot_comparison(
    metric_by_planner: Dict[str, Sequence[float]],
    metric_name: str = "scalarised cost",
    save_path: Optional[str] = None,
) -> None:
    """Grouped box plot of one metric across planners."""

    labels = list(metric_by_planner.keys())
    data = [np.asarray(v, dtype=np.float64) for v in metric_by_planner.values()]
    data = [d[np.isfinite(d)] for d in data]
    fig, ax = plt.subplots(figsize=(5.5, 4.2))
    ax.boxplot(data, tick_labels=labels, showmeans=True)
    ax.set_ylabel(metric_name)
    ax.set_title(f"{metric_name} by planner")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=150)
    plt.close(fig)
