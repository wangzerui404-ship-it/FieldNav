"""Differentiable physical-field models used to constrain UAV trajectories.

Each field is a smooth, closed-form function of world position so that (a) it
can be sampled anywhere along a continuous path and (b) its gradients are
trivially available for future differentiable-planner extensions.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .config import FieldConfig


class GaussianMixture:
    """Sum of isotropic Gaussian kernels plus a uniform background."""

    def __init__(
        self,
        centers: np.ndarray,
        amplitudes: np.ndarray,
        sigmas: np.ndarray,
        base: float,
    ) -> None:
        self.centers = np.asarray(centers, dtype=np.float64).reshape(-1, 3)
        self.amplitudes = np.asarray(amplitudes, dtype=np.float64).reshape(-1)
        self.sigmas = np.asarray(sigmas, dtype=np.float64).reshape(-1)
        self.base = float(base)

    def evaluate(self, points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=np.float64).reshape(-1, 3)
        out = np.full(points.shape[0], self.base, dtype=np.float64)
        for c, a, s in zip(self.centers, self.amplitudes, self.sigmas):
            d2 = np.sum((points - c[None, :]) ** 2, axis=1)
            out = out + a * np.exp(-d2 / (2.0 * s * s))
        return out


class ScalarField:
    """A non-negative scalar intensity field (thermal, EMI, ...)."""

    def __init__(self, name: str, mixture: GaussianMixture, clip: Tuple[float, float] = (0.0, 1.0)) -> None:
        self.name = name
        self.mixture = mixture
        self.clip = clip

    def sample(self, points: np.ndarray) -> np.ndarray:
        v = self.mixture.evaluate(points)
        lo, hi = self.clip
        return np.clip(v, lo, hi)


class SignalField(ScalarField):
    """Connectivity strength in [0, 1]; 1 means full link quality."""

    def __init__(self, mixture: GaussianMixture) -> None:
        super().__init__("signal", mixture, clip=(0.0, 1.0))


class WindField:
    """Smooth 3-D wind vector field: background wind + Gaussian gusts."""

    def __init__(
        self,
        background: np.ndarray,
        centers: np.ndarray,
        amplitudes: np.ndarray,
        sigmas: np.ndarray,
        directions: np.ndarray,
    ) -> None:
        self.background = np.asarray(background, dtype=np.float64).reshape(3)
        self.centers = np.asarray(centers, dtype=np.float64).reshape(-1, 3)
        self.amplitudes = np.asarray(amplitudes, dtype=np.float64).reshape(-1)
        self.sigmas = np.asarray(sigmas, dtype=np.float64).reshape(-1)
        self.directions = np.asarray(directions, dtype=np.float64).reshape(-1, 3)

    def vector(self, points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=np.float64).reshape(-1, 3)
        out = np.tile(self.background[None, :], (points.shape[0], 1))
        for c, a, s, d in zip(self.centers, self.amplitudes, self.sigmas, self.directions):
            d2 = np.sum((points - c[None, :]) ** 2, axis=1)
            out += (a * np.exp(-d2 / (2.0 * s * s)))[:, None] * d[None, :]
        return out


class FieldSet:
    """Container for all enabled fields plus convenience vectorised sampling."""

    SCALAR_NAMES = ("thermal", "emi", "signal")

    def __init__(
        self,
        wind: Optional[WindField] = None,
        thermal: Optional[ScalarField] = None,
        emi: Optional[ScalarField] = None,
        signal: Optional[SignalField] = None,
    ) -> None:
        self.wind = wind
        self.thermal = thermal
        self.emi = emi
        self.signal = signal

    def enabled(self) -> List[str]:
        names: List[str] = []
        for name in self.SCALAR_NAMES:
            if getattr(self, name) is not None:
                names.append(name)
        return names

    def scalars(self, points: np.ndarray) -> Dict[str, np.ndarray]:
        return {name: getattr(self, name).sample(points) for name in self.enabled()}

    def wind_vector(self, points: np.ndarray) -> np.ndarray:
        if self.wind is None:
            return np.zeros((np.asarray(points).reshape(-1, 3).shape[0], 3))
        return self.wind.vector(points)

    def scalar_stack(self, points: np.ndarray) -> np.ndarray:
        """Stack enabled scalar fields as ``(N, n_enabled)`` in canonical order."""

        cols = [getattr(self, name).sample(points) for name in self.SCALAR_NAMES if getattr(self, name) is not None]
        if not cols:
            return np.zeros((np.asarray(points).reshape(-1, 3).shape[0], 0))
        return np.stack(cols, axis=1)

    # ----- serialization ---------------------------------------------------
    def to_state(self) -> Dict[str, Any]:
        """Serialize field parameters so scenarios can be saved/loaded exactly."""

        state: Dict[str, Any] = {}
        if self.wind is not None:
            state["wind"] = {
                "background": self.wind.background.tolist(),
                "centers": self.wind.centers.tolist(),
                "amplitudes": self.wind.amplitudes.tolist(),
                "sigmas": self.wind.sigmas.tolist(),
                "directions": self.wind.directions.tolist(),
            }
        for name in self.SCALAR_NAMES:
            field = getattr(self, name)
            if field is not None:
                state[name] = {
                    "centers": field.mixture.centers.tolist(),
                    "amplitudes": field.mixture.amplitudes.tolist(),
                    "sigmas": field.mixture.sigmas.tolist(),
                    "base": field.mixture.base,
                    "clip": list(field.clip),
                }
        return state

    @staticmethod
    def from_state(state: Dict[str, Any]) -> "FieldSet":
        wind = None
        if "wind" in state:
            s = state["wind"]
            wind = WindField(
                background=np.asarray(s["background"]),
                centers=np.asarray(s["centers"]),
                amplitudes=np.asarray(s["amplitudes"]),
                sigmas=np.asarray(s["sigmas"]),
                directions=np.asarray(s["directions"]),
            )

        def scalar(name: str) -> Optional[ScalarField]:
            if name not in state:
                return None
            s = state[name]
            mixture = GaussianMixture(
                centers=np.asarray(s["centers"]),
                amplitudes=np.asarray(s["amplitudes"]),
                sigmas=np.asarray(s["sigmas"]),
                base=float(s["base"]),
            )
            if name == "signal":
                return SignalField(mixture)
            return ScalarField(name, mixture, clip=tuple(s.get("clip", (0.0, 1.0))))

        return FieldSet(
            wind=wind,
            thermal=scalar("thermal"),
            emi=scalar("emi"),
            signal=scalar("signal"),
        )


def generate_fields(cfg: FieldConfig, rng: np.random.Generator, bounds: Tuple[float, ...]) -> FieldSet:
    """Create a random ``FieldSet`` respecting the ``FieldConfig`` toggles."""

    xmin, xmax, ymin, ymax, zmin, zmax = bounds

    def rand_centers(k: int) -> np.ndarray:
        return np.stack(
            [
                rng.uniform(xmin, xmax, size=k),
                rng.uniform(ymin, ymax, size=k),
                rng.uniform(zmin + 2.0, zmax - 2.0, size=k),
            ],
            axis=1,
        )

    def amplitudes(k: int) -> np.ndarray:
        return rng.uniform(*cfg.source_strength, size=k)

    def sigmas(k: int) -> np.ndarray:
        return rng.uniform(*cfg.source_radius, size=k)

    k = cfg.n_sources

    wind = None
    if cfg.wind:
        dirs = rng.normal(size=(k, 3))
        dirs /= np.linalg.norm(dirs, axis=1, keepdims=True) + 1e-8
        wind = WindField(
            background=rng.uniform(-2.0, 2.0, size=3),
            centers=rand_centers(k),
            amplitudes=rng.uniform(1.0, 4.0, size=k),
            sigmas=sigmas(k),
            directions=dirs,
        )

    thermal = None
    if cfg.thermal:
        thermal = ScalarField("thermal", GaussianMixture(rand_centers(k), amplitudes(k), sigmas(k), cfg.base_value))

    emi = None
    if cfg.emi:
        emi = ScalarField("emi", GaussianMixture(rand_centers(k), amplitudes(k), sigmas(k), cfg.base_value))

    signal = None
    if cfg.signal:
        # Signal should be strong near sources; model it as 1 - attenuation.
        mixture = GaussianMixture(rand_centers(k), amplitudes(k), sigmas(k), cfg.base_value)
        signal = SignalField(mixture)

    return FieldSet(wind=wind, thermal=thermal, emi=emi, signal=signal)
