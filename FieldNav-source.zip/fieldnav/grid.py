"""3-D voxel grid and occupancy primitives."""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np


class Grid3D:
    """A uniform voxel grid over an axis-aligned world-space bounding box.

    World coordinates are ``(x, y, z)`` with z pointing up.  Voxel indices are
    ``(ix, iy, iz)`` and flatten to ``ix + nx * (iy + ny * iz)``.
    """

    def __init__(
        self,
        bounds: Tuple[float, float, float, float, float, float],
        resolution: float,
        occupied: Optional[np.ndarray] = None,
    ) -> None:
        self.xmin, self.xmax, self.ymin, self.ymax, self.zmin, self.zmax = bounds
        self.resolution = float(resolution)
        self.nx = int(round((self.xmax - self.xmin) / self.resolution))
        self.ny = int(round((self.ymax - self.ymin) / self.resolution))
        self.nz = int(round((self.zmax - self.zmin) / self.resolution))
        self.shape = (self.nx, self.ny, self.nz)
        self.n_nodes = self.nx * self.ny * self.nz
        self.occupied = (
            np.zeros(self.shape, dtype=bool) if occupied is None else occupied.astype(bool)
        )
        self._neighbors: Optional[np.ndarray] = None

    # ----- coordinate conversions -----------------------------------------
    def cell(self, x: float, y: float, z: float) -> Tuple[int, int, int]:
        ix = int(np.clip(np.floor((x - self.xmin) / self.resolution), 0, self.nx - 1))
        iy = int(np.clip(np.floor((y - self.ymin) / self.resolution), 0, self.ny - 1))
        iz = int(np.clip(np.floor((z - self.zmin) / self.resolution), 0, self.nz - 1))
        return ix, iy, iz

    def center(self, ix: int, iy: int, iz: int) -> np.ndarray:
        return np.array(
            [
                self.xmin + (ix + 0.5) * self.resolution,
                self.ymin + (iy + 0.5) * self.resolution,
                self.zmin + (iz + 0.5) * self.resolution,
            ],
            dtype=np.float64,
        )

    def to_index(self, ix: int, iy: int, iz: int) -> int:
        return ix + self.nx * (iy + self.ny * iz)

    def from_index(self, idx: int) -> Tuple[int, int, int]:
        iz, rem = divmod(idx, self.nx * self.ny)
        iy, ix = divmod(rem, self.nx)
        return ix, iy, iz

    def world_to_index(self, x: float, y: float, z: float) -> int:
        ix, iy, iz = self.cell(x, y, z)
        return self.to_index(ix, iy, iz)

    def index_to_world(self, idx: int) -> np.ndarray:
        return self.center(*self.from_index(idx))

    def in_bounds(self, ix: int, iy: int, iz: int) -> bool:
        return 0 <= ix < self.nx and 0 <= iy < self.ny and 0 <= iz < self.nz

    # ----- occupancy --------------------------------------------------------
    def set_occupied(self, ix: int, iy: int, iz: int, value: bool = True) -> None:
        if self.in_bounds(ix, iy, iz):
            self.occupied[ix, iy, iz] = value

    def is_free(self, idx: int) -> bool:
        if not 0 <= idx < self.n_nodes:
            return False
        ix, iy, iz = self.from_index(idx)
        return not self.occupied[ix, iy, iz]

    def free_mask(self) -> np.ndarray:
        return ~self.occupied.ravel()

    # ----- graph connectivity ---------------------------------------------
    def _build_neighbors(self) -> np.ndarray:
        """Precompute ``(n_nodes, k)`` neighbour table; -1 marks invalid cells."""

        nbh = np.full((self.n_nodes, 26), -1, dtype=np.int64)
        offsets = [
            (dx, dy, dz)
            for dx in (-1, 0, 1)
            for dy in (-1, 0, 1)
            for dz in (-1, 0, 1)
            if not (dx == 0 and dy == 0 and dz == 0)
        ]
        for ix in range(self.nx):
            for iy in range(self.ny):
                for iz in range(self.nz):
                    idx = self.to_index(ix, iy, iz)
                    for k, (dx, dy, dz) in enumerate(offsets):
                        jx, jy, jz = ix + dx, iy + dy, iz + dz
                        if self.in_bounds(jx, jy, jz):
                            nbh[idx, k] = self.to_index(jx, jy, jz)
        return nbh

    @property
    def neighbors(self) -> np.ndarray:
        if self._neighbors is None:
            self._neighbors = self._build_neighbors()
        return self._neighbors

    def neighbor_list(self, idx: int) -> List[int]:
        row = self.neighbors[idx]
        return [int(j) for j in row if j >= 0]

    def neighbor_offsets(self) -> List[Tuple[int, int, int]]:
        return [
            (dx, dy, dz)
            for dx in (-1, 0, 1)
            for dy in (-1, 0, 1)
            for dz in (-1, 0, 1)
            if not (dx == 0 and dy == 0 and dz == 0)
        ]

    # ----- geometric queries -----------------------------------------------
    def segment_collides(
        self, a: np.ndarray, b: np.ndarray, clearance: float = 0.5
    ) -> bool:
        """True if the segment ``a->b`` passes through an occupied voxel.

        Samples the segment at half-voxel spacing, which is conservative enough
        for voxelised obstacle sets.
        """

        length = float(np.linalg.norm(b - a))
        if length < 1e-9:
            idx = self.world_to_index(*a)
            return not self.is_free(idx)
        steps = max(2, int(np.ceil(length / (self.resolution * 0.5))))
        for t in np.linspace(0.0, 1.0, steps + 1):
            p = a + t * (b - a)
            ix, iy, iz = self.cell(*p)
            if self.occupied[ix, iy, iz]:
                return True
        return False

    def nearest_free_index(self, x: float, y: float, z: float) -> int:
        """Snap a world point to the closest free voxel (BFS over the grid)."""

        ix, iy, iz = self.cell(x, y, z)
        start = self.to_index(ix, iy, iz)
        if self.is_free(start):
            return start
        # Small BFS outwards; caps the search at a sane radius.
        from collections import deque

        seen = {start}
        queue = deque([start])
        while queue:
            cur = queue.popleft()
            for nxt in self.neighbor_list(cur):
                if nxt in seen:
                    continue
                seen.add(nxt)
                if self.is_free(nxt):
                    return nxt
                queue.append(nxt)
        raise ValueError("no free voxel found in grid")
