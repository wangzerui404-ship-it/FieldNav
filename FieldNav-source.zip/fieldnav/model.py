"""Torch MLP that regresses the scalarised cost-to-go (the neural heuristic)."""

from __future__ import annotations

from typing import Optional

import torch
from torch import nn

from .config import ModelConfig


class CostToGoNet(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int = 128, n_layers: int = 3) -> None:
        super().__init__()
        layers = [nn.Linear(in_dim, hidden_dim), nn.ReLU()]
        for _ in range(max(1, n_layers - 1)):
            layers += [nn.Linear(hidden_dim, hidden_dim), nn.ReLU()]
        layers += [nn.Linear(hidden_dim, 1)]
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


def build_model(in_dim: int, cfg: ModelConfig, seed: Optional[int] = None) -> CostToGoNet:
    if seed is not None:
        torch.manual_seed(seed)
    return CostToGoNet(in_dim, hidden_dim=cfg.hidden_dim, n_layers=cfg.n_layers)
