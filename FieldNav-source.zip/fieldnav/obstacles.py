"""Procedural 3-D obstacle generation (buildings, towers, balloons, terrain)."""

from __future__ import annotations

from typing import Tuple

import numpy as np

from .config import ObstacleConfig
from .grid import Grid3D


def _add_box(
    grid: Grid3D,
    center: np.ndarray,
    half_extents: np.ndarray,
) -> None:
    lo = grid.cell(*(center - half_extents))
    hi = grid.cell(*(center + half_extents))
    for ix in range(lo[0], hi[0] + 1):
        for iy in range(lo[1], hi[1] + 1):
            for iz in range(lo[2], hi[2] + 1):
                if grid.in_bounds(ix, iy, iz):
                    grid.occupied[ix, iy, iz] = True


def _add_cylinder(
    grid: Grid3D,
    center: np.ndarray,
    radius: float,
    height: float,
) -> None:
    """Vertical cylinder rising from z=0."""

    lo = grid.cell(center[0] - radius, center[1] - radius, 0.0)
    hi = grid.cell(center[0] + radius, center[1] + radius, height)
    r2 = radius * radius
    for ix in range(lo[0], hi[0] + 1):
        for iy in range(lo[1], hi[1] + 1):
            px, py, _ = grid.center(ix, iy, 0)
            if (px - center[0]) ** 2 + (py - center[1]) ** 2 <= r2:
                for iz in range(lo[2], hi[2] + 1):
                    if grid.in_bounds(ix, iy, iz):
                        grid.occupied[ix, iy, iz] = True


def _add_sphere(grid: Grid3D, center: np.ndarray, radius: float) -> None:
    lo = grid.cell(*(center - radius))
    hi = grid.cell(*(center + radius))
    r2 = radius * radius
    for ix in range(lo[0], hi[0] + 1):
        for iy in range(lo[1], hi[1] + 1):
            for iz in range(lo[2], hi[2] + 1):
                p = grid.center(ix, iy, iz)
                if grid.in_bounds(ix, iy, iz) and float(np.sum((p - center) ** 2)) <= r2:
                    grid.occupied[ix, iy, iz] = True


def generate_obstacles(
    grid: Grid3D,
    cfg: ObstacleConfig,
    rng: np.random.Generator,
) -> None:
    """Fill ``grid.occupied`` with a procedural urban obstacle field."""

    grid.occupied.fill(False)
    xmin, xmax, ymin, ymax, zmin, zmax = (
        grid.xmin,
        grid.xmax,
        grid.ymin,
        grid.ymax,
        grid.zmin,
        grid.zmax,
    )

    def rand_xy() -> np.ndarray:
        return np.array(
            [rng.uniform(xmin + 5, xmax - 5), rng.uniform(ymin + 5, ymax - 5)]
        )

    # Box buildings.
    for _ in range(cfg.n_boxes):
        c = rand_xy()
        half = rng.uniform(3.0, 10.0, size=2)
        h = rng.uniform(*cfg.box_height_range)
        center = np.array([c[0], c[1], h / 2.0])
        _add_box(grid, center, np.array([half[0], half[1], h / 2.0]))

    # Vertical cylinders (towers / chimneys / trees).
    for _ in range(cfg.n_cylinders):
        c = rand_xy()
        r = rng.uniform(2.0, 6.0)
        h = rng.uniform(*cfg.cylinder_height_range)
        _add_cylinder(grid, np.array([c[0], c[1], 0.0]), r, h)

    # Floating / grounded spheres (balloons, radomes).
    for _ in range(cfg.n_spheres):
        c = rand_xy()
        r = rng.uniform(*cfg.sphere_radius_range)
        z = rng.uniform(5.0, zmax - 5.0)
        _add_sphere(grid, np.array([c[0], c[1], z]), r)

    # Ground plane and a thin obstacle-free clearance layer above it.
    ground_iz = max(0, int(round(cfg.ground_clearance / grid.resolution)))
    for iz in range(ground_iz):
        if 0 <= iz < grid.nz:
            grid.occupied[:, :, iz] = True
