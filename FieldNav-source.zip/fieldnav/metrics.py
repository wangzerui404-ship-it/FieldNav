"""Evaluation metrics and aggregation for the benchmark."""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from .config import Config
from .cost import COST_NAMES, path_cost_vector
from .env import Scenario


def path_metrics(
    points: np.ndarray,
    scenario: Scenario,
    weights: np.ndarray,
) -> Dict[str, float]:
    """Five objective values plus scalarised cost and geometric length."""

    if len(points) == 0:
        return {"cost": float("inf"), "length": float("inf"), **{n: float("inf") for n in COST_NAMES[1:]}}
    cvec = path_cost_vector(points, scenario.fields, scenario.dyn, scenario.cost_cfg)
    out = {name: float(cvec[i]) for i, name in enumerate(COST_NAMES)}
    out["cost"] = float(np.dot(cvec, weights))
    out["length"] = float(cvec[0])
    return out


def aggregate(rows: List[Dict[str, float]]) -> Dict[str, float]:
    """Mean over scenario rows, handling inf/NaN (failed runs)."""

    agg: Dict[str, float] = {}
    for key in rows[0]:
        vals = np.asarray([r.get(key, float("nan")) for r in rows], dtype=np.float64)
        vals = vals[np.isfinite(vals)]
        agg[key] = float(vals.mean()) if vals.size else float("nan")
    return agg


def format_table(rows: List[Dict[str, float]]) -> str:
    """Render a compact aligned table for console and docs."""

    if not rows:
        return ""
    keys = list(rows[0].keys())
    header = " | ".join(keys)
    sep = "-" * len(header)
    lines = [header, sep]
    for r in rows:
        cells = []
        for k in keys:
            v = r[k]
            cells.append("inf" if not np.isfinite(v) else f"{v:.3f}")
        lines.append(" | ".join(cells))
    return "\n".join(lines)
