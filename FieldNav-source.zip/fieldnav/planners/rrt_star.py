"""Anytime RRT* in continuous space with field-aware edge cost."""

from __future__ import annotations

import time
from typing import Dict, Optional, Sequence, Tuple

import numpy as np

from ..cost import segment_cost_vector
from ..dynamics import steer
from ..env import Scenario


def rrt_star(
    scenario: Scenario,
    weights: Sequence[float],
    iterations: int = 3000,
    max_dist: float = 6.0,
    goal_bias: float = 0.15,
    rewire_radius: float = 25.0,
    goal_tol: float = 3.0,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """Sample-based asymptotically-optimal planner; returns ``(path, stats)``."""

    grid = scenario.grid
    fields = scenario.fields
    dyn = scenario.dyn
    cost_cfg = scenario.cost_cfg
    w = np.asarray(weights, dtype=np.float64)
    rng = np.random.default_rng(scenario.seed + 7)
    lo = np.array([grid.xmin, grid.ymin, grid.zmin])
    hi = np.array([grid.xmax, grid.ymax, grid.zmax])
    start = scenario.start
    goal = scenario.goal

    t0 = time.perf_counter()
    nodes = [start]
    parent = [-1]
    cost = [0.0]

    def edge(p: np.ndarray, q: np.ndarray) -> float:
        cvec = segment_cost_vector(p, q, fields, dyn, cost_cfg)
        return float(np.dot(cvec, w))

    best_path: Optional[np.ndarray] = None
    best_cost = float("inf")

    for it in range(iterations):
        if rng.random() < goal_bias:
            sample = goal
        else:
            sample = rng.uniform(lo, hi)

        # Nearest node (brute-force is fine at benchmark scale).
        dists = np.linalg.norm(np.asarray(nodes) - sample[None, :], axis=1)
        nearest = int(np.argmin(dists))
        new_point = steer(nodes[nearest], sample, max_dist)
        if grid.segment_collides(nodes[nearest], new_point):
            continue

        new_cost = cost[nearest] + edge(nodes[nearest], new_point)
        new_idx = len(nodes)
        nodes.append(new_point)
        parent.append(nearest)
        cost.append(new_cost)

        # Rewire nearby nodes through the new node.
        for j in range(len(nodes) - 1):
            if j == nearest:
                continue
            if np.linalg.norm(nodes[j] - new_point) > rewire_radius:
                continue
            cand = new_cost + edge(new_point, nodes[j])
            if cand < cost[j] and not grid.segment_collides(new_point, nodes[j]):
                cost[j] = cand
                parent[j] = new_idx

        # Try connecting the new node to the goal.
        if np.linalg.norm(new_point - goal) <= goal_tol and not grid.segment_collides(new_point, goal):
            cand = new_cost + edge(new_point, goal)
            if cand < best_cost:
                best_cost = cand
                path_idx = [new_idx]
                cur = new_idx
                while cur != 0:
                    cur = parent[cur]
                    path_idx.append(cur)
                path_idx.reverse()
                pts = [nodes[i] for i in path_idx] + [goal]
                best_path = np.stack(pts)

    stats: Dict[str, float] = {
        "nodes": float(len(nodes)),
        "time_s": time.perf_counter() - t0,
        "iterations": float(iterations),
    }
    if best_path is None:
        return np.zeros((0, 3)), {**stats, "cost": float("inf"), "path_length_m": float("inf")}

    from ..cost import path_cost_vector

    stats["cost"] = float(np.dot(path_cost_vector(best_path, fields, dyn, cost_cfg), w))
    stats["path_length_m"] = float(np.sum(np.linalg.norm(np.diff(best_path, axis=0), axis=1)))
    return best_path, stats
