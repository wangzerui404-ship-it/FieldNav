"""A* accelerated by a learned cost-to-go heuristic."""

from __future__ import annotations

from typing import Callable, Dict, Sequence, Tuple

import numpy as np
import torch

from ..env import Scenario
from .search import a_star


class NeuralHeuristic:
    """Maps a grid node index to a predicted cost-to-go using a trained net."""

    def __init__(self, model: torch.nn.Module, scenario: Scenario, scale: float = 1.0) -> None:
        self.model = model
        self.scenario = scenario
        self.scale = scale
        self.model.eval()
        self._features = torch.from_numpy(scenario.feature_matrix())

    @torch.no_grad()
    def __call__(self, idx: int) -> float:
        x = self._features[idx : idx + 1]
        return self.scale * float(self.model(x).item())


def neural_a_star(
    scenario: Scenario,
    heuristic: Callable[[int], float],
    weights: Sequence[float],
    eps: float = 1.5,
    start_idx: int | None = None,
    goal_idx: int | None = None,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """Weighted A* with the learned (possibly inadmissible) heuristic."""

    return a_star(
        scenario,
        weights,
        heuristic=lambda idx: eps * heuristic(idx),
        eps=1.0,
        start_idx=start_idx,
        goal_idx=goal_idx,
    )
