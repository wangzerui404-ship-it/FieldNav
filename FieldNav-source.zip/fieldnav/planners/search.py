"""Graph-search planners over the voxel grid.

``a_star`` solves the scalarised problem exactly under an admissible,
consistent heuristic.  ``cost_to_go`` runs a backward Dijkstra to obtain the
ground-truth cost-to-go used to supervise the neural heuristic.
``multi_objective_a_star`` performs Pareto label-setting and returns a set of
non-dominated paths.

All graph planners share the same precomputed per-node field cache, so their
edge costs coincide exactly with the continuous path evaluator
(``fieldnav.cost.path_cost_vector``).
"""

from __future__ import annotations

import heapq
import itertools
import time
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from ..config import CostConfig, DynamicsConfig
from ..cost import segment_cost_from_cache
from ..env import Scenario
from ..grid import Grid3D


def _prepare(scenario: Scenario):
    grid = scenario.grid
    centers = np.stack([grid.index_to_world(i) for i in range(grid.n_nodes)])
    wind = scenario.fields.wind_vector(centers)
    scalars = scenario.fields.scalars(centers)
    return centers, wind, scalars


def edge_cost(
    u: int,
    v: int,
    centers: np.ndarray,
    wind: np.ndarray,
    scalars: Dict[str, np.ndarray],
    dyn: DynamicsConfig,
    cost_cfg: CostConfig,
    weights: np.ndarray,
) -> float:
    cvec = segment_cost_from_cache(u, v, centers, wind, scalars, dyn, cost_cfg)
    return float(np.dot(cvec, weights))


def admissible_heuristic(
    grid: Grid3D,
    weights: Sequence[float],
    goal_idx: int,
    centers: np.ndarray,
) -> Callable[[int], float]:
    """Euclidean lower bound using the minimum per-metre cost multiplier."""

    min_mult = float(weights[0]) + float(weights[1])
    goal = centers[goal_idx]
    return lambda idx: min_mult * float(np.linalg.norm(centers[idx] - goal))


def _reconstruct(parent: Dict[int, int], goal_idx: int) -> List[int]:
    path = [goal_idx]
    while path[-1] in parent:
        path.append(parent[path[-1]])
    path.reverse()
    return path


def a_star(
    scenario: Scenario,
    weights: Sequence[float],
    heuristic: Optional[Callable[[int], float]] = None,
    eps: float = 1.0,
    start_idx: Optional[int] = None,
    goal_idx: Optional[int] = None,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """Scalarised A*; returns ``(path_points, stats)``."""

    grid = scenario.grid
    dyn = scenario.dyn
    cost_cfg = scenario.cost_cfg
    w = np.asarray(weights, dtype=np.float64)
    centers, wind, scalars = _prepare(scenario)
    start = scenario.start_idx if start_idx is None else int(start_idx)
    goal = scenario.goal_idx if goal_idx is None else int(goal_idx)
    if heuristic is None:
        heuristic = admissible_heuristic(grid, w, goal, centers)

    t0 = time.perf_counter()
    g_score: Dict[int, float] = {start: 0.0}
    parent: Dict[int, int] = {}
    closed = set()
    counter = itertools.count()
    open_heap: List[Tuple[float, int, int]] = [(eps * heuristic(start), next(counter), start)]
    expanded = 0

    while open_heap:
        f, _, cur = heapq.heappop(open_heap)
        if cur in closed:
            continue
        if cur == goal:
            path_idx = _reconstruct(parent, goal)
            points = np.stack([grid.index_to_world(i) for i in path_idx])
            stats = {
                "nodes_expanded": float(expanded),
                "time_s": time.perf_counter() - t0,
                "path_length_m": float(np.sum(np.linalg.norm(np.diff(points, axis=0), axis=1))),
                "cost": g_score[cur],
            }
            return points, stats
        closed.add(cur)
        expanded += 1
        for nxt in grid.neighbor_list(cur):
            if not grid.is_free(nxt) or nxt in closed:
                continue
            tentative = g_score[cur] + edge_cost(cur, nxt, centers, wind, scalars, dyn, cost_cfg, w)
            if tentative < g_score.get(nxt, float("inf")):
                g_score[nxt] = tentative
                parent[nxt] = cur
                heapq.heappush(open_heap, (tentative + eps * heuristic(nxt), next(counter), nxt))

    return np.zeros((0, 3)), {
        "nodes_expanded": float(expanded),
        "time_s": time.perf_counter() - t0,
        "cost": float("inf"),
    }


def cost_to_go(
    scenario: Scenario,
    weights: Sequence[float],
    goal_idx: Optional[int] = None,
) -> np.ndarray:
    """Backward Dijkstra: cost-to-go from every free voxel to the goal."""

    grid = scenario.grid
    dyn = scenario.dyn
    cost_cfg = scenario.cost_cfg
    w = np.asarray(weights, dtype=np.float64)
    centers, wind, scalars = _prepare(scenario)
    goal = scenario.goal_idx if goal_idx is None else int(goal_idx)

    dist = np.full(grid.n_nodes, np.inf)
    dist[goal] = 0.0
    heap: List[Tuple[float, int]] = [(0.0, goal)]

    while heap:
        du, u = heapq.heappop(heap)
        if du > dist[u]:
            continue
        for v in grid.neighbor_list(u):
            if not grid.is_free(v):
                continue
            nd = du + edge_cost(v, u, centers, wind, scalars, dyn, cost_cfg, w)
            if nd < dist[v] - 1e-12:
                dist[v] = nd
                heapq.heappush(heap, (nd, v))
    return dist


def multi_objective_a_star(
    scenario: Scenario,
    max_labels: int = 64,
    max_expansions: int = 20000,
    start_idx: Optional[int] = None,
    goal_idx: Optional[int] = None,
) -> Tuple[List[np.ndarray], np.ndarray]:
    """Pareto-optimal path set via multi-objective label-setting A*.

    Returns ``(paths, cost_matrix)`` where each row of ``cost_matrix`` is the
    5-objective cost vector of the corresponding non-dominated path.
    """

    from ..cost import dominates

    grid = scenario.grid
    dyn = scenario.dyn
    cost_cfg = scenario.cost_cfg
    centers, wind, scalars = _prepare(scenario)
    start = scenario.start_idx if start_idx is None else int(start_idx)
    goal = scenario.goal_idx if goal_idx is None else int(goal_idx)

    labels: Dict[int, Dict[int, np.ndarray]] = {}
    parents: Dict[int, Dict[int, Tuple[int, int]]] = {}
    counter = itertools.count()
    heap: List[Tuple[float, int, int, int]] = []  # (scalarized, counter, node, label_id)
    labels[start] = {0: np.zeros(5)}
    next_label_id = 1

    heapq.heappush(heap, (0.0, next(counter), start, 0))
    goal_labels: Dict[int, np.ndarray] = {}
    goal_parents: List[Tuple[int, int]] = []
    expansions = 0

    while heap and expansions < max_expansions:
        _, _, node, label_id = heapq.heappop(heap)
        node_labels = labels.get(node, {})
        if label_id not in node_labels:
            continue  # label was pruned by dominance
        expansions += 1
        cost_vec = node_labels[label_id]
        if node == goal:
            if not any(dominates(c, cost_vec) for c in goal_labels.values()):
                for gid in [g for g, c in goal_labels.items() if dominates(cost_vec, c)]:
                    del goal_labels[gid]
                goal_labels[label_id] = cost_vec.copy()
                goal_parents = [(n, i) for (n, i) in goal_parents if i in goal_labels]
                goal_parents.append((node, label_id))
            continue
        for nxt in grid.neighbor_list(node):
            if not grid.is_free(nxt):
                continue
            cvec = segment_cost_from_cache(node, nxt, centers, wind, scalars, dyn, cost_cfg)
            new_cost = cost_vec + cvec
            existing = labels.get(nxt, {})
            if any(dominates(c, new_cost) for c in existing.values()):
                continue
            for eid in [e for e, c in existing.items() if dominates(new_cost, c)]:
                del existing[eid]
            if len(existing) >= max_labels:
                continue
            new_id = next_label_id
            next_label_id += 1
            existing[new_id] = new_cost
            labels[nxt] = existing
            parents.setdefault(nxt, {})[new_id] = (node, label_id)
            heapq.heappush(heap, (float(new_cost.sum()), next(counter), nxt, new_id))

    paths: List[np.ndarray] = []
    for (g_node, g_id) in goal_parents:
        if g_id not in labels.get(g_node, {}):
            continue
        path = [g_node]
        cur_node, cur_id = g_node, g_id
        while cur_node != start:
            p_node, p_id = parents.get(cur_node, {}).get(cur_id, (start, 0))
            path.append(p_node)
            cur_node, cur_id = p_node, p_id
        path.reverse()
        paths.append(np.stack([grid.index_to_world(i) for i in path]))
    if not paths:
        return [], np.zeros((0, 5))
    cost_matrix = np.stack(
        [labels[goal][gid] for (goal, gid) in goal_parents if gid in labels.get(goal, {})]
    )
    return paths, cost_matrix
