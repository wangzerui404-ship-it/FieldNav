# FieldNav

**物理场约束的多目标无人机路径规划**：在风场、热场、电磁干扰与通信链路约束下
自动避障，并用可学习的神经启发式加速精确搜索。

[English](README.md) · [方法](docs/METHODOLOGY.md) · [数据集](docs/DATASET.md) ·
[实验](docs/EXPERIMENTS.md) · [API](docs/API.md)

## 简介

FieldNav 把无人机路径规划建模为**连续可微物理场上的多目标最短路径问题**，包含：

1. 带可采纳启发式的**精确标量化 A***；
2. 返回帕累托最优路径集合的**多目标 A***（标签设置法）；
3. 连续空间、场感知的**RRT***；
4. 由精确搜索模仿训练出的 **神经 A***（cost-to-go 网络），以少量最优性代价换取
   展开节点数和墙钟时间的大幅下降。

## 快速开始

```bash
git clone https://github.com/<你的账号>/FieldNav.git
cd FieldNav
python -m pip install -r requirements.txt

python scripts/generate_dataset.py --config configs/default.yaml --n 20 --out data/raw
python scripts/train.py --config configs/train.yaml
python scripts/evaluate.py --config configs/benchmark.yaml \
    --checkpoint results/checkpoints/neural_heuristic.pt --out results
python scripts/demo.py --config configs/default.yaml \
    --checkpoint results/checkpoints/neural_heuristic.pt --out outputs
```

运行测试：`python -m pytest tests -q`。

## 主要结果（真实复现，20 个未见场景）

| 规划器 | 标量化代价 | 最优性差距 | 展开节点 | 耗时(s) |
| --- | ---: | ---: | ---: | ---: |
| A*（精确） | 348.02 | —（最优） | 3253 | 0.31 |
| **神经 A*** | 367.23 | **+5.5%** | **143** | **0.09** |
| RRT* | 386.13 | +11.5% | — | 13.65 |

神经 A* 展开节点数约为精确 A* 的 **1/23**，速度快约 **3.4 倍**，最优性代价仅
5.5%，同时优于 RRT*。详细逐场景数据、训练曲线与局限讨论见
[docs/EXPERIMENTS.md](docs/EXPERIMENTS.md)。

## 许可

MIT，见 [LICENSE](LICENSE)。
