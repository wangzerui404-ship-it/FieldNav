# One-command upload helper.
# Usage (PowerShell, in this folder):
#   .\upload.ps1 -RepoUrl https://github.com/<your-account>/FieldNav.git
param(
    [Parameter(Mandatory = $true)][string]$RepoUrl
)

$ErrorActionPreference = "Stop"

if (Test-Path .git) {
    Remove-Item -Recurse -Force .git
}

git init -b main
git add -A
git -c user.name="zeruiwang-science" -c user.email="1045686071@qq.com" `
    commit -m "Initial release: FieldNav - physics-field-aware multi-objective UAV path planning"
git remote add origin $RepoUrl
git push -u origin main

Write-Host ""
Write-Host "Done. Open $RepoUrl to confirm."
