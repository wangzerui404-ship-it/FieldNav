# 上传到 GitHub（最后一步需要你本人操作）

所有代码、数据脚本、预训练权重和真实实验结果都已经准备好，放在本项目目录里。
我无法替你完成 `git push`，原因有三：

1. 这个运行环境默认连不上 GitHub（443 被墙）；
2. 我没有、也不应持有你 GitHub 账号的密码或 Token；
3. 本沙盒把项目的 `.git` 目录设为只读，我也无法在这里替你生成提交。

所以只需要你在自己的电脑上跑一条命令。下面给两种方式，任选其一。

## 方式 A：一条 PowerShell 脚本（推荐）

先在你的电脑上把整个项目文件夹复制过去（或用 `outputs/FieldNav-source.zip`），
然后在该文件夹里打开 PowerShell，执行：

```powershell
.\upload.ps1 -RepoUrl https://github.com/<你的账号>/FieldNav.git
```

脚本会：删除临时 `.git` → 重新 `git init` → 提交所有文件 → 关联远端 → 推送。
首次推送时若提示输入用户名/密码，用户名填 GitHub 用户名，密码粘贴你的
Personal Access Token。

## 方式 B：手动三步

1. 打开 https://github.com/new 新建一个**空**仓库 `FieldNav`
   （不要勾选 README / .gitignore / license）。
2. 准备访问凭据：https://github.com/settings/tokens?type=beta
   生成 Fine-grained token，Repository access 选刚建的仓库，Contents 权限
   设为 Read and write，复制 `github_pat_...`。
3. 在本项目文件夹里执行：

```bash
git init -b main
git add -A
git commit -m "Initial release: FieldNav"
git remote add origin https://github.com/<你的账号>/FieldNav.git
git push -u origin main
```

## 推送后（建议，帮助涨 star）

- 仓库 Settings 里开启 Issues / Discussions，加 topics：
  `uav`、`path-planning`、`drone`、`astar`、`rrt-star`、`multi-objective`。
- 把 `README.md` 里的 `<your-account>` 占位符替换成你的真实账号名。
- 发布时附上一张 `outputs/demo_3d.png` 效果图。

> 说明：我不会、也无法替你刷 star 或伪造实验数据。README 中的 benchmark 数字
> 全部是本机真实跑出来的，可用 `scripts/train.py` 和 `scripts/evaluate.py` 一键复现。
