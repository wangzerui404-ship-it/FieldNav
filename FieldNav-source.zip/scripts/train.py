"""Train the neural cost-to-go heuristic.

Usage:  python scripts/train.py --config configs/train.yaml
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fieldnav.config import load_config
from fieldnav.train import train
from fieldnav.viz import plot_training_curve


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/train.yaml")
    ap.add_argument("--data-dir", default="data/raw")
    ap.add_argument("--checkpoint-dir", default="results/checkpoints")
    ap.add_argument("--history", default="results/training_history.json")
    args = ap.parse_args()

    cfg = load_config(args.config)
    out = train(cfg, data_dir=args.data_dir, checkpoint_dir=args.checkpoint_dir)
    with open(args.history, "w", encoding="utf-8") as fh:
        json.dump(out["history"], fh, indent=2)
    plot_training_curve(out["history"], save_path="results/figures/training_curve.png")
    print(f"checkpoint: {out['checkpoint']}")
    print(f"history:    {args.history}")


if __name__ == "__main__":
    main()
