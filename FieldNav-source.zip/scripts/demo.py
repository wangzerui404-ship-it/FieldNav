"""Single-scenario demo with figures.

Usage:  python scripts/demo.py --config configs/default.yaml \
            --checkpoint results/checkpoints/neural_heuristic.pt --out outputs
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from fieldnav.config import load_config
from fieldnav.env import Scenario
from fieldnav.evaluate import load_checkpoint
from fieldnav.planners.neural import NeuralHeuristic, neural_a_star
from fieldnav.planners.rrt_star import rrt_star
from fieldnav.planners.search import a_star, multi_objective_a_star
from fieldnav.utils import set_seed
from fieldnav.viz import plot_2d, plot_3d


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="outputs")
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(args.seed)
    os.makedirs(args.out, exist_ok=True)

    scenario = Scenario.generate(args.seed, cfg)
    weights = np.asarray(cfg.cost.vector, dtype=np.float64)
    paths = {}

    path_exact, _ = a_star(scenario, weights)
    paths["A* (exact)"] = path_exact

    if args.checkpoint and os.path.exists(args.checkpoint):
        model, scale = load_checkpoint(args.checkpoint)
        path_neural, _ = neural_a_star(
            scenario, NeuralHeuristic(model, scenario, scale), weights, eps=cfg.planner.weighted_astar_eps
        )
        paths["Neural A*"] = path_neural

    path_rrt, _ = rrt_star(
        scenario,
        weights,
        iterations=cfg.planner.rrt_star_iterations,
        max_dist=cfg.grid.resolution * 1.5,
        goal_bias=cfg.planner.rrt_star_goal_bias,
        rewire_radius=cfg.planner.rrt_star_radius,
    )
    paths["RRT*"] = path_rrt

    plot_2d(scenario, paths, field_name="thermal", save_path=os.path.join(args.out, "demo_2d_thermal.png"))
    plot_2d(scenario, paths, field_name="signal", save_path=os.path.join(args.out, "demo_2d_signal.png"))
    plot_3d(scenario, paths, save_path=os.path.join(args.out, "demo_3d.png"))

    # Pareto set on a coarser grid for a tractable multi-objective showcase.
    cfg.grid.resolution = 8.0
    coarse = Scenario.generate(args.seed, cfg)
    mo_paths, mo_costs = multi_objective_a_star(coarse, max_labels=6, max_expansions=8000)
    if mo_paths:
        mo_map = {f"Pareto #{i+1}": p for i, p in enumerate(mo_paths[:5])}
        plot_2d(coarse, mo_map, field_name="thermal", save_path=os.path.join(args.out, "demo_pareto_2d.png"))
    print(f"wrote figures to {args.out}")


if __name__ == "__main__":
    main()
