"""Generate a dataset of random planning scenarios.

Usage:  python scripts/generate_dataset.py --config configs/default.yaml \
            --n 20 --seed 0 --out data/raw
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fieldnav.config import load_config
from fieldnav.data import generate_scenarios
from fieldnav.utils import set_seed


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="data/raw")
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(args.seed)
    os.makedirs(args.out, exist_ok=True)
    generate_scenarios(args.n, args.seed, cfg, out_dir=args.out)
    print(f"wrote {args.n} scenarios to {args.out}")


if __name__ == "__main__":
    main()
