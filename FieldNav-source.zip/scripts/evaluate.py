"""Run the planner benchmark.

Usage:  python scripts/evaluate.py --config configs/benchmark.yaml \
            --checkpoint results/checkpoints/neural_heuristic.pt --out results
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fieldnav.config import load_config
from fieldnav.evaluate import evaluate


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/benchmark.yaml")
    ap.add_argument("--checkpoint", default="results/checkpoints/neural_heuristic.pt")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    cfg = load_config(args.config)
    result = evaluate(cfg, checkpoint_path=args.checkpoint, out_dir=args.out)
    agg = result["aggregate"]
    print("aggregate metrics:")
    for k, v in agg.items():
        print(f"  {k}: {v:.4f}")
    print(f"metrics saved to {result['metrics_path']}")


if __name__ == "__main__":
    main()
