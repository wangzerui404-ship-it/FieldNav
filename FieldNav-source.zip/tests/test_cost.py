import numpy as np

from fieldnav.config import Config, CostConfig, DynamicsConfig
from fieldnav.cost import (
    COST_NAMES,
    dominates,
    pareto_filter,
    path_cost_vector,
    scalarized_cost,
    segment_cost_vector,
)
from fieldnav.env import Scenario


def test_segment_cost_basics():
    cfg = Config()
    s = Scenario.generate(0, cfg)
    a = np.array([0.0, 0.0, 10.0])
    b = np.array([3.0, 4.0, 10.0])
    c = segment_cost_vector(a, b, s.fields, s.dyn, s.cost_cfg)
    assert c.shape == (5,)
    assert np.all(c >= 0)
    assert np.isclose(c[0], 5.0)  # length == Euclidean distance
    assert c[1] >= c[0]  # energy >= length


def test_path_and_scalarized_cost_agree():
    cfg = Config()
    s = Scenario.generate(1, cfg)
    pts = np.array([[0, 0, 5], [5, 0, 6], [10, 2, 8]], dtype=float)
    cvec = path_cost_vector(pts, s.fields, s.dyn, s.cost_cfg)
    assert cvec.shape == (5,)
    w = np.asarray(cfg.cost.vector)
    assert np.isclose(scalarized_cost(pts, s.fields, s.dyn, s.cost_cfg, w), float(np.dot(cvec, w)))


def test_pareto_helpers():
    costs = np.array([[1.0, 5.0], [1.0, 4.0], [2.0, 2.0]])
    assert dominates(costs[1], costs[0])
    kept = pareto_filter(costs)
    assert 0 not in kept  # dominated by row 1
