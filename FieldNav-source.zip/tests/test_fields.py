import numpy as np

from fieldnav.config import Config
from fieldnav.fields import FieldSet, generate_fields


def test_generate_fields_shapes_and_ranges():
    cfg = Config()
    cfg.fields.n_sources = 4
    rng = np.random.default_rng(0)
    fields = generate_fields(cfg.fields, rng, cfg.grid.bounds)
    pts = rng.uniform(-20, 20, size=(100, 3))
    pts[:, 2] = rng.uniform(1, 70, size=100)

    wind = fields.wind_vector(pts)
    assert wind.shape == (100, 3)

    scalars = fields.scalars(pts)
    assert set(scalars) == {"thermal", "emi", "signal"}
    assert np.all(scalars["thermal"] >= 0)
    assert np.all(scalars["emi"] >= 0)
    assert np.all((scalars["signal"] >= 0) & (scalars["signal"] <= 1))


def test_field_serialization_roundtrip():
    cfg = Config()
    cfg.fields.n_sources = 3
    rng = np.random.default_rng(7)
    fields = generate_fields(cfg.fields, rng, cfg.grid.bounds)
    restored = FieldSet.from_state(fields.to_state())
    pts = rng.uniform(-30, 30, size=(20, 3))
    assert np.allclose(fields.wind_vector(pts), restored.wind_vector(pts))
    for name in ("thermal", "emi", "signal"):
        assert np.allclose(fields.scalars(pts)[name], restored.scalars(pts)[name])
