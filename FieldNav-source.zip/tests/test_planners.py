import numpy as np

from fieldnav.config import Config
from fieldnav.env import Scenario
from fieldnav.planners.rrt_star import rrt_star
from fieldnav.planners.search import a_star, cost_to_go


def _small_scenario(seed=0):
    cfg = Config()
    cfg.grid.resolution = 10.0
    cfg.obstacles.n_boxes = 2
    cfg.obstacles.n_cylinders = 1
    cfg.obstacles.n_spheres = 0
    return Scenario.generate(seed, cfg), cfg


def test_astar_returns_path():
    s, cfg = _small_scenario()
    w = np.asarray(cfg.cost.vector)
    points, stats = a_star(s, w)
    assert points.shape[1] == 3
    assert stats["cost"] < float("inf")
    assert len(points) >= 2


def test_cost_to_go_goal_zero():
    s, cfg = _small_scenario()
    w = np.asarray(cfg.cost.vector)
    dist = cost_to_go(s, w)
    assert dist[s.goal_idx] == 0.0
    assert np.isfinite(dist[s.start_idx])


def test_rrt_star_runs():
    s, cfg = _small_scenario()
    w = np.asarray(cfg.cost.vector)
    points, stats = rrt_star(s, w, iterations=200, max_dist=12.0)
    assert stats["nodes"] > 0
